package com.ls89.paintjavanide;


//code for webview 

import android.app.Activity;
import android.os.Bundle;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        
        // Enable JavaScript
        webSettings.setJavaScriptEnabled(true);  
        
        // Ensure links open in WebView
        webView.setWebViewClient(new WebViewClient()); 

        // Load the local HTML file from the assets folder
        webView.loadUrl("file:///android_asset/index.html");
    }

}