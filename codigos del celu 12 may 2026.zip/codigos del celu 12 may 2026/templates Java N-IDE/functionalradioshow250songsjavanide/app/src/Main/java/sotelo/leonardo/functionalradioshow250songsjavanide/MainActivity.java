package sotelo.leonardo.functionalradioshow250songsjavanide;

//replace all after package reference with this code 
import android.app.Activity;
import android.os.Bundle;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import android.view.View;
import android.webkit.JavascriptInterface;




public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        
        // Enable JavaScript
        webSettings.setJavaScriptEnabled(true);  
        
        // Ensure links open in WebView
        webView.setWebViewClient(new WebViewClient()); 

//Javascriptinterface named Android 
webView.addJavascriptInterface(new WebAppInterface(), "Android");


        // Load the local HTML file from the assets folder
        webView.loadUrl("file:///android_asset/index.html");
        
   
         // Hide status bar and navigation bar
    hideSystemUI();

  } 



private void hideSystemUI() {
   
    // Enables regular immersive mode.
    
    // For "lean back" mode, remove 
    //SYSTEM_UI_FLAG_IMMERSIVE
   
    // Or for "sticky immersive" replace it with
    // SYSTEM_UI_FLAG_IMMERSIVE_STICKY
   
    View decorView = getWindow().getDecorView();
   
    decorView.setSystemUiVisibility(
          
            View.SYSTEM_UI_FLAG_IMMERSIVE
          
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
           
            | View.SYSTEM_UI_FLAG_FULLSCREEN
           
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
           
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
         
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
  
    );
}






   public class WebAppInterface { 

   @JavascriptInterface 
   public void closeWebView() { 

   finish(); // Close the activity 
   }
   }
 

}
