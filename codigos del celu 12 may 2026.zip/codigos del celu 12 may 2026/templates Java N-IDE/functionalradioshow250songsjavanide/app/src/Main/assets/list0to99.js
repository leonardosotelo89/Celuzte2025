const list1 = []  
  
 list1[0] = { 
   intro:['introsone/rosesareredintro1.mp3', 
          'introsone/rosesareredintro2.mp3',  
          'introsone/rosesareredintro3.mp3', 
          'introsone/rosesareredintro4.mp3',  
          'introsone/rosesareredintro5.mp3', 
          'introsone/rosesareredintro6.mp3',  
          'introsone/rosesareredintro7.mp3', 
          'introsone/rosesareredintro8.mp3',  
          'introsone/rosesareredintro9.mp3', 
          'introsone/rosesareredintro10.mp3',  
          'introsone/rosesareredintro11.mp3'], 
   song:'aquarosesarered.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: dinamarca (🇩🇰) / interprete: aqua / cancion: roses are red &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[1] = { 
   intro:['introsone/yalanintro1.mp3', 
          'introsone/yalanintro2.mp3',  
          'introsone/yalanintro3.mp3', 
          'introsone/yalanintro4.mp3',  
          'introsone/yalanintro5.mp3', 
          'introsone/yalanintro6.mp3',  
          'introsone/yalanintro7.mp3', 
          'introsone/yalanintro8.mp3',  
          'introsone/yalanintro9.mp3', 
          'introsone/yalanintro10.mp3',  
          'introsone/yalanintro11.mp3', 
          'introsone/yalanintro12.mp3'], 
   song:'edisyalan.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Turquía (🇹🇷) / interprete: Edis / cancion: Yalan &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[2] = { 
   intro:['introsone/sotokorintro1.mp3', 
          'introsone/sotokorintro2.mp3',  
          'introsone/sotokorintro3.mp3', 
          'introsone/sotokorintro4.mp3',  
          'introsone/sotokorintro5.mp3', 
          'introsone/sotokorintro6.mp3',  
          'introsone/sotokorintro7.mp3', 
          'introsone/sotokorintro8.mp3',  
          'introsone/sotokorintro9.mp3', 
          'introsone/sotokorintro10.mp3',  
          'introsone/sotokorintro11.mp3', 
          'introsone/sotokorintro12.mp3'], 
   song:'fardinsaadatsotokor.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: Fardin Saadat / cancion: Soto Kor &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[3] = { 
   intro:['introsone/tymenyazabudintro1.mp3', 
          'introsone/tymenyazabudintro2.mp3',  
          'introsone/tymenyazabudintro3.mp3', 
          'introsone/tymenyazabudintro4.mp3',  
          'introsone/tymenyazabudintro5.mp3', 
          'introsone/tymenyazabudintro6.mp3',  
          'introsone/tymenyazabudintro7.mp3', 
          'introsone/tymenyazabudintro8.mp3',  
          'introsone/tymenyazabudintro9.mp3', 
          'introsone/tymenyazabudintro10.mp3',  
          'introsone/tymenyazabudintro11.mp3', 
          'introsone/tymenyazabudintro12.mp3'],  
   song:'djpiligrimtymenyazabud.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Uzbekistan (🇺🇿) / interprete: dj piligrim / cancion: ty menya zabud &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[4] = { 
   intro:['introsone/oynasunintro1.mp3', 
          'introsone/oynasunintro2.mp3',  
          'introsone/oynasunintro3.mp3', 
          'introsone/oynasunintro4.mp3',  
          'introsone/oynasunintro5.mp3', 
          'introsone/oynasunintro6.mp3',  
          'introsone/oynasunintro7.mp3', 
          'introsone/oynasunintro8.mp3',  
          'introsone/oynasunintro9.mp3', 
          'introsone/oynasunintro10.mp3',  
          'introsone/oynasunintro11.mp3', 
          'introsone/oynasunintro12.mp3',  
          'introsone/oynasunintro13.mp3'],  
   song:'shahrizodaoynasun.mp3', 
   text:"&nbsp&nbsp&nbsp&#160&#160&#160 pais: Uzbekistan (🇺🇿) / interprete: Shahrizoda / cancion: oynasun &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[5] = { 
   intro:['introsone/boroborointro1.mp3', 
          'introsone/boroborointro2.mp3',  
          'introsone/boroborointro3.mp3', 
          'introsone/boroborointro4.mp3',  
          'introsone/boroborointro5.mp3', 
          'introsone/boroborointro6.mp3',  
          'introsone/boroborointro7.mp3', 
          'introsone/boroborointro8.mp3',  
          'introsone/boroborointro9.mp3', 
          'introsone/boroborointro10.mp3',  
          'introsone/boroborointro11.mp3', 
          'introsone/boroborointro12.mp3'],  
   song:'arashboroboro.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: arash / cancion: boro boro &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[6] = { 
   intro:['introsone/krasotadushiintro1.mp3', 
          'introsone/krasotadushiintro2.mp3',  
          'introsone/krasotadushiintro3.mp3', 
          'introsone/krasotadushiintro4.mp3',  
          'introsone/krasotadushiintro5.mp3', 
          'introsone/krasotadushiintro6.mp3',  
          'introsone/krasotadushiintro7.mp3', 
          'introsone/krasotadushiintro8.mp3',  
          'introsone/krasotadushiintro9.mp3', 
          'introsone/krasotadushiintro10.mp3',  
          'introsone/krasotadushiintro11.mp3', 
          'introsone/krasotadushiintro12.mp3',  
          'introsone/krasotadushiintro13.mp3'],  
   song:'fatimaypieraijokrasotadushi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima y pier aijo / cancion: krasota dushi &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[7] = { 
   intro:['introsone/ageberiintro1.mp3', 
          'introsone/ageberiintro2.mp3',  
          'introsone/ageberiintro3.mp3', 
          'introsone/ageberiintro4.mp3',  
          'introsone/ageberiintro5.mp3', 
          'introsone/ageberiintro6.mp3',  
          'introsone/ageberiintro7.mp3', 
          'introsone/ageberiintro8.mp3',  
          'introsone/ageberiintro9.mp3', 
          'introsone/ageberiintro10.mp3',  
          'introsone/ageberiintro11.mp3'],  
   song:'maziarsammeageberi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: maziar samme / cancion: age beri &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[8] = { 
   intro:['introsone/manobavarkonintro1.mp3', 
          'introsone/manobavarkonintro2.mp3',  
          'introsone/manobavarkonintro3.mp3', 
          'introsone/manobavarkonintro4.mp3',  
          'introsone/manobavarkonintro5.mp3', 
          'introsone/manobavarkonintro6.mp3',  
          'introsone/manobavarkonintro7.mp3', 
          'introsone/manobavarkonintro8.mp3',  
          'introsone/manobavarkonintro9.mp3', 
          'introsone/manobavarkonintro10.mp3',  
          'introsone/manobavarkonintro11.mp3', 
          'introsone/manobavarkonintro12.mp3'],  
   song:'pouyabayatimanobavarkon.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: pouya bayati / cancion: mano bavar kon &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[9] = { 
   intro:['introsone/bimarefatintro1.mp3', 
          'introsone/bimarefatintro2.mp3',  
          'introsone/bimarefatintro3.mp3', 
          'introsone/bimarefatintro4.mp3',  
          'introsone/bimarefatintro5.mp3', 
          'introsone/bimarefatintro6.mp3',  
          'introsone/bimarefatintro7.mp3', 
          'introsone/bimarefatintro8.mp3',  
          'introsone/bimarefatintro9.mp3', 
          'introsone/bimarefatintro10.mp3',  
          'introsone/bimarefatintro11.mp3', 
          'introsone/bimarefatintro12.mp3',  
          'introsone/bimarefatintro13.mp3'],  
   song:'aliabdolmalekibimarefat.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: ali abdolmaleki / cancion: bi marefat &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[10] = { 
   intro:['introsone/macalinaintro1.mp3', 
          'introsone/macalinaintro2.mp3',  
          'introsone/macalinaintro3.mp3', 
          'introsone/macalinaintro4.mp3',  
          'introsone/macalinaintro5.mp3', 
          'introsone/macalinaintro6.mp3',  
          'introsone/macalinaintro7.mp3', 
          'introsone/macalinaintro8.mp3',  
          'introsone/macalinaintro9.mp3', 
          'introsone/macalinaintro10.mp3',  
          'introsone/macalinaintro11.mp3'],  
   song:'kendjigiracmacalina.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: kendji girac / cancion: ma calina &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[11] = { 
   intro:['introsone/andalouseintro1.mp3', 
          'introsone/andalouseintro2.mp3',  
          'introsone/andalouseintro3.mp3', 
          'introsone/andalouseintro4.mp3',  
          'introsone/andalouseintro5.mp3', 
          'introsone/andalouseintro6.mp3',  
          'introsone/andalouseintro7.mp3', 
          'introsone/andalouseintro8.mp3',  
          'introsone/andalouseintro9.mp3', 
          'introsone/andalouseintro10.mp3',  
          'introsone/andalouseintro11.mp3', 
          'introsone/andalouseintro12.mp3',  
          'introsone/andalouseintro13.mp3'],  
   song:'kendjigiracandalouse.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: kendji girac / cancion: andalouse &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[12] = { 
   intro:['introsone/vibrasdelcaribeintro1.mp3', 
          'introsone/vibrasdelcaribeintro2.mp3',   
          'introsone/vibrasdelcaribeintro3.mp3',   
          'introsone/vibrasdelcaribeintro4.mp3',    
          'introsone/vibrasdelcaribeintro5.mp3',    
          'introsone/vibrasdelcaribeintro6.mp3',    
          'introsone/vibrasdelcaribeintro7.mp3',    
          'introsone/vibrasdelcaribeintro8.mp3',    
          'introsone/vibrasdelcaribeintro9.mp3',   
          'introsone/vibrasdelcaribeintro10.mp3',    
          'introsone/vibrasdelcaribeintro11.mp3',    
          'introsone/vibrasdelcaribeintro12.mp3',    
          'introsone/vibrasdelcaribeintro13.mp3',    
          'introsone/vibrasdelcaribeintro14.mp3',    
          'introsone/vibrasdelcaribeintro15.mp3' ],    
   song:'emozikvibrasdelcaribe.mp3',   
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bangladesh (🇧🇩) / interprete: Emozik / cancion: Vibras del Caribe  &nbsp&nbsp&nbsp&#160&#160&#160"   
 }  

 list1[13] = { 
   intro:['introsone/allaboutusintro1.mp3', 
          'introsone/allaboutusintro2.mp3',  
          'introsone/allaboutusintro3.mp3', 
          'introsone/allaboutusintro4.mp3',  
          'introsone/allaboutusintro5.mp3', 
          'introsone/allaboutusintro6.mp3',  
          'introsone/allaboutusintro7.mp3', 
          'introsone/allaboutusintro8.mp3',  
          'introsone/allaboutusintro9.mp3', 
          'introsone/allaboutusintro10.mp3',  
          'introsone/allaboutusintro11.mp3' ],  
   song:'tatuallaboutus.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: tatu / cancion: all about us &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[14] = { 
   intro:['introsone/allthethingsshesaidintro1.mp3', 
          'introsone/allthethingsshesaidintro2.mp3',  
          'introsone/allthethingsshesaidintro3.mp3', 
          'introsone/allthethingsshesaidintro4.mp3',  
          'introsone/allthethingsshesaidintro5.mp3', 
          'introsone/allthethingsshesaidintro6.mp3',  
          'introsone/allthethingsshesaidintro7.mp3', 
          'introsone/allthethingsshesaidintro8.mp3',  
          'introsone/allthethingsshesaidintro9.mp3', 
          'introsone/allthethingsshesaidintro10.mp3',  
          'introsone/allthethingsshesaidintro11.mp3'],  
   song:'tatuallthethingsshesaid.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: tatu / cancion: all the things she said &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[15] = { 
   intro:['introsone/pahaltapiilossaintro1.mp3', 
          'introsone/pahaltapiilossaintro2.mp3',  
          'introsone/pahaltapiilossaintro3.mp3', 
          'introsone/pahaltapiilossaintro4.mp3',  
          'introsone/pahaltapiilossaintro5.mp3', 
          'introsone/pahaltapiilossaintro6.mp3',  
          'introsone/pahaltapiilossaintro7.mp3', 
          'introsone/pahaltapiilossaintro8.mp3',  
          'introsone/pahaltapiilossaintro9.mp3', 
          'introsone/pahaltapiilossaintro10.mp3',  
          'introsone/pahaltapiilossaintro11.mp3', 
          'introsone/pahaltapiilossaintro12.mp3'],  
   song:'suviterasniskapahaltapiilossa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: finlandia (🇫🇮) / interprete: suvi terasniska / cancion: pahalta piilossa &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[16] = { 
   intro:['introsone/tirnanogintro1.mp3', 
          'introsone/tirnanogintro2.mp3',  
          'introsone/tirnanogintro3.mp3', 
          'introsone/tirnanogintro4.mp3',  
          'introsone/tirnanogintro5.mp3', 
          'introsone/tirnanogintro6.mp3',  
          'introsone/tirnanogintro7.mp3', 
          'introsone/tirnanogintro8.mp3',  
          'introsone/tirnanogintro9.mp3', 
          'introsone/tirnanogintro10.mp3',  
          'introsone/tirnanogintro11.mp3', 
          'introsone/tirnanogintro12.mp3'],  
   song:'celticwomantirnanog.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: irlanda (🇮🇪) / interprete: celtic woman / cancion: tir na nog &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[17] = { 
   intro:['introsone/naachmeriraniintro1.mp3', 
          'introsone/naachmeriraniintro2.mp3',  
          'introsone/naachmeriraniintro3.mp3', 
          'introsone/naachmeriraniintro4.mp3',  
          'introsone/naachmeriraniintro5.mp3', 
          'introsone/naachmeriraniintro6.mp3',  
          'introsone/naachmeriraniintro7.mp3', 
          'introsone/naachmeriraniintro8.mp3',  
          'introsone/naachmeriraniintro9.mp3', 
          'introsone/naachmeriraniintro10.mp3',  
          'introsone/naachmeriraniintro11.mp3', 
          'introsone/naachmeriraniintro12.mp3'],  
   song:'gururandhawaynorafatehinaachmerirani.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) - canada (🇨🇦) / interprete: guru randhawa y nora fatehi / cancion: naach meri rani &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[18] = { 
   intro:['introsone/tandangintro1.mp3', 
          'introsone/tandangintro2.mp3',  
          'introsone/tandangintro3.mp3', 
          'introsone/tandangintro4.mp3',  
          'introsone/tandangintro5.mp3', 
          'introsone/tandangintro6.mp3',  
          'introsone/tandangintro7.mp3', 
          'introsone/tandangintro8.mp3',  
          'introsone/tandangintro9.mp3', 
          'introsone/tandangintro10.mp3',  
          'introsone/tandangintro11.mp3', 
          'introsone/tandangintro12.mp3',  
          'introsone/tandangintro13.mp3'],  
   song:'djk8remixcaojintandang.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: djk8 remix cao jin / cancion: tandang &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[19] = { 
   intro:['introsone/boshretkheirintro1.mp3', 
          'introsone/boshretkheirintro2.mp3',  
          'introsone/boshretkheirintro3.mp3', 
          'introsone/boshretkheirintro4.mp3',  
          'introsone/boshretkheirintro5.mp3', 
          'introsone/boshretkheirintro6.mp3',  
          'introsone/boshretkheirintro7.mp3', 
          'introsone/boshretkheirintro8.mp3',  
          'introsone/boshretkheirintro9.mp3', 
          'introsone/boshretkheirintro10.mp3',  
          'introsone/boshretkheirintro11.mp3', 
          'introsone/boshretkheirintro12.mp3'],  
   song:'djmusaliboshretkheir.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: emiratos arabes unidos (🇦🇪) / interprete: dj musali (black arabia) / cancion: boshret kheir &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[20] = { 
   intro:['introsone/venavenaintro1.mp3', 
          'introsone/venavenaintro2.mp3',  
          'introsone/venavenaintro3.mp3', 
          'introsone/venavenaintro4.mp3',  
          'introsone/venavenaintro5.mp3', 
          'introsone/venavenaintro6.mp3',  
          'introsone/venavenaintro7.mp3', 
          'introsone/venavenaintro8.mp3',  
          'introsone/venavenaintro9.mp3', 
          'introsone/venavenaintro10.mp3',  
          'introsone/venavenaintro11.mp3'],  
   song:'sozersepetcivenavena.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: sözer sepetçi / cancion: vêna vêna &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[21] = { 
   intro:['introsone/amenointro1.mp3', 
          'introsone/amenointro2.mp3',  
          'introsone/amenointro3.mp3', 
          'introsone/amenointro4.mp3',  
          'introsone/amenointro5.mp3', 
          'introsone/amenointro6.mp3',  
          'introsone/amenointro7.mp3', 
          'introsone/amenointro8.mp3',  
          'introsone/amenointro9.mp3', 
          'introsone/amenointro10.mp3',  
          'introsone/amenointro11.mp3'],  
   song:'eraameno.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: era / cancion: ameno &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[22] = { 
   intro:['introsone/xanaduintro1.mp3', 
          'introsone/xanaduintro2.mp3',  
          'introsone/xanaduintro3.mp3', 
          'introsone/xanaduintro4.mp3',  
          'introsone/xanaduintro5.mp3', 
          'introsone/xanaduintro6.mp3',  
          'introsone/xanaduintro7.mp3', 
          'introsone/xanaduintro8.mp3',  
          'introsone/xanaduintro9.mp3', 
          'introsone/xanaduintro10.mp3',  
          'introsone/xanaduintro11.mp3', 
          'introsone/xanaduintro12.mp3',  
          'introsone/xanaduintro13.mp3'],  
   song:'ummetozcanxanadu.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: holanda (🇳🇱) / interprete: ummet ozcan / cancion: xanadu &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[23] = { 
   intro:['introsone/ayimointro1.mp3', 
          'introsone/ayimointro2.mp3', 
          'introsone/ayimointro3.mp3',  
          'introsone/ayimointro4.mp3', 
          'introsone/ayimointro5.mp3', 
          'introsone/ayimointro6.mp3', 
          'introsone/ayimointro7.mp3', 
          'introsone/ayimointro8.mp3', 
          'introsone/ayimointro9.mp3',  
          'introsone/ayimointro10.mp3', 
          'introsone/ayimointro11.mp3', 
          'introsone/ayimointro12.mp3'],  
   song:'grupoajitaiayimo.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: grupo ajitai / cancion: ayimo &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[24] = { 
   intro:['introsone/daritezhenshchinamtsvetyintro1.mp3', 
          'introsone/daritezhenshchinamtsvetyintro2.mp3',  
          'introsone/daritezhenshchinamtsvetyintro3.mp3', 
          'introsone/daritezhenshchinamtsvetyintro4.mp3', 
          'introsone/daritezhenshchinamtsvetyintro5.mp3', 
          'introsone/daritezhenshchinamtsvetyintro6.mp3',  
          'introsone/daritezhenshchinamtsvetyintro7.mp3', 
          'introsone/daritezhenshchinamtsvetyintro8.mp3',  
          'introsone/daritezhenshchinamtsvetyintro9.mp3', 
          'introsone/daritezhenshchinamtsvetyintro10.mp3',  
          'introsone/daritezhenshchinamtsvetyintro11.mp3'],  
   song:'jazzdaurendaritezhenshchinamtsvety.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Kazajistán (🇰🇿) / interprete: jazzdauren / cancion: darite zhenshchinam tsvety &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[25] = { 
   intro:['introsone/gulyanananeyintro1.mp3', 
          'introsone/gulyanananeyintro2.mp3',  
          'introsone/gulyanananeyintro3.mp3', 
          'introsone/gulyanananeyintro4.mp3',  
          'introsone/gulyanananeyintro5.mp3', 
          'introsone/gulyanananeyintro6.mp3',  
          'introsone/gulyanananeyintro7.mp3', 
          'introsone/gulyanananeyintro8.mp3',  
          'introsone/gulyanananeyintro9.mp3', 
          'introsone/gulyanananeyintro10.mp3',  
          'introsone/gulyanananeyintro11.mp3'],  
   song:'gulyanananey.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: gulya / cancion: na na ney &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[26] = { 
   intro:['introsone/yallaintro1.mp3', 
          'introsone/yallaintro2.mp3',  
          'introsone/yallaintro3.mp3', 
          'introsone/yallaintro4.mp3',  
          'introsone/yallaintro5.mp3', 
          'introsone/yallaintro6.mp3',  
          'introsone/yallaintro7.mp3', 
          'introsone/yallaintro8.mp3',  
          'introsone/yallaintro9.mp3', 
          'introsone/yallaintro10.mp3',  
          'introsone/yallaintro11.mp3', 
          'introsone/yallaintro12.mp3',  
          'introsone/yallaintro13.mp3'],  
   song:'innayalla.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: inna / cancion: yalla &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[27] = { 
   intro:['introsone/uyghurdancemixintro1.mp3', 
          'introsone/uyghurdancemixintro2.mp3',  
          'introsone/uyghurdancemixintro3.mp3', 
          'introsone/uyghurdancemixintro4.mp3',  
          'introsone/uyghurdancemixintro5.mp3', 
          'introsone/uyghurdancemixintro6.mp3',  
          'introsone/uyghurdancemixintro7.mp3', 
          'introsone/uyghurdancemixintro8.mp3',  
          'introsone/uyghurdancemixintro9.mp3', 
          'introsone/uyghurdancemixintro10.mp3',  
          'introsone/uyghurdancemixintro11.mp3', 
          'introsone/uyghurdancemixintro12.mp3',  
          'introsone/uyghurdancemixintro13.mp3'],  
   song:'ablimitjanmemetuyghurdancemix.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: ablimitjan memet / cancion: uyghur dance &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[28] = { 
   intro:['introsone/derindarbeintro1.mp3', 
          'introsone/derindarbeintro2.mp3',  
          'introsone/derindarbeintro3.mp3', 
          'introsone/derindarbeintro4.mp3',  
          'introsone/derindarbeintro5.mp3', 
          'introsone/derindarbeintro6.mp3',  
          'introsone/derindarbeintro7.mp3', 
          'introsone/derindarbeintro8.mp3',  
          'introsone/derindarbeintro9.mp3', 
          'introsone/derindarbeintro10.mp3',  
          'introsone/derindarbeintro11.mp3', 
          'introsone/derindarbeintro12.mp3',  
          'introsone/derindarbeintro13.mp3'],  
   song:'tugbaozerkderindarbe.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: Tuğba Özerk / cancion: derin darbe &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[29] = { 
   intro:['introsone/gamsizintro1.mp3', 
          'introsone/gamsizintro2.mp3',  
          'introsone/gamsizintro3.mp3', 
          'introsone/gamsizintro4.mp3',  
          'introsone/gamsizintro5.mp3', 
          'introsone/gamsizintro6.mp3',  
          'introsone/gamsizintro7.mp3', 
          'introsone/gamsizintro8.mp3',  
          'introsone/gamsizintro9.mp3', 
          'introsone/gamsizintro10.mp3',  
          'introsone/gamsizintro11.mp3'],  
   song:'hilalcebeciydogusgamsiz.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: Hilal Cebeci y Doğuş / cancion: gamsiz &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[30] = { 
   intro:['introsone/madinabuibuiintro1.mp3', 
          'introsone/madinabuibuiintro2.mp3',  
          'introsone/madinabuibuiintro3.mp3', 
          'introsone/madinabuibuiintro4.mp3',  
          'introsone/madinabuibuiintro5.mp3', 
          'introsone/madinabuibuiintro6.mp3',  
          'introsone/madinabuibuiintro7.mp3', 
          'introsone/madinabuibuiintro8.mp3',  
          'introsone/madinabuibuiintro9.mp3', 
          'introsone/madinabuibuiintro10.mp3',  
          'introsone/madinabuibuiintro11.mp3' ],  
   song:'madinaibragimovabuibui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: madina ibragimova / cancion: bui-bui &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[31] = { 
   intro:['introsone/tristarbuibuiintro1.mp3', 
          'introsone/tristarbuibuiintro2.mp3',  
          'introsone/tristarbuibuiintro3.mp3', 
          'introsone/tristarbuibuiintro4.mp3',  
          'introsone/tristarbuibuiintro5.mp3', 
          'introsone/tristarbuibuiintro6.mp3',  
          'introsone/tristarbuibuiintro7.mp3', 
          'introsone/tristarbuibuiintro8.mp3',  
          'introsone/tristarbuibuiintro9.mp3', 
          'introsone/tristarbuibuiintro10.mp3',  
          'introsone/tristarbuibuiintro11.mp3'],  
   song:'grupotristarbuibui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: kirguistan (🇰🇬) / interprete: grupo tristar / cancion: bui-bui &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[32] = { 
   intro:['introsone/mechtyotebeintro1.mp3', 
          'introsone/mechtyotebeintro2.mp3',  
          'introsone/mechtyotebeintro3.mp3', 
          'introsone/mechtyotebeintro4.mp3',  
          'introsone/mechtyotebeintro5.mp3', 
          'introsone/mechtyotebeintro6.mp3',  
          'introsone/mechtyotebeintro7.mp3', 
          'introsone/mechtyotebeintro8.mp3',  
          'introsone/mechtyotebeintro9.mp3', 
          'introsone/mechtyotebeintro10.mp3',  
          'introsone/mechtyotebeintro11.mp3'],  
   song:'fatimarabadanovaypieraijomechtyotebe.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima rabadanova y pier aijo / cancion: mechty o tebe &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[33] = { 
   intro:['introsone/izdaxmayliaginadoslaintro1.mp3', 
          'introsone/izdaxmayliaginadoslaintro2.mp3',  
          'introsone/izdaxmayliaginadoslaintro3.mp3', 
          'introsone/izdaxmayliaginadoslaintro4.mp3',  
          'introsone/izdaxmayliaginadoslaintro5.mp3', 
          'introsone/izdaxmayliaginadoslaintro6.mp3',  
          'introsone/izdaxmayliaginadoslaintro7.mp3', 
          'introsone/izdaxmayliaginadoslaintro8.mp3',  
          'introsone/izdaxmayliaginadoslaintro9.mp3', 
          'introsone/izdaxmayliaginadoslaintro10.mp3',  
          'introsone/izdaxmayliaginadoslaintro11.mp3'],  
   song:'yusupaliroziizdaxmayliaginadosla.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: yusup ali rozi / cancion: izdaxmayli agina dosla &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[34] = { 
   intro:['introsone/oynaoynaintro1.mp3', 
          'introsone/oynaoynaintro2.mp3',  
          'introsone/oynaoynaintro3.mp3', 
          'introsone/oynaoynaintro4.mp3',  
          'introsone/oynaoynaintro5.mp3', 
          'introsone/oynaoynaintro6.mp3',  
          'introsone/oynaoynaintro7.mp3', 
          'introsone/oynaoynaintro8.mp3',  
          'introsone/oynaoynaintro9.mp3', 
          'introsone/oynaoynaintro10.mp3',  
          'introsone/oynaoynaintro11.mp3', 
          'introsone/oynaoynaintro12.mp3', 
          'introsone/oynaoynaintro13.mp3', 
          'introsone/oynaoynaintro14.mp3', 
          'introsone/oynaoynaintro15.mp3'],  
   song:'maratsautovoyna.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Kazajistán (🇰🇿) / interprete: Marat Sautov / cancion: oyna oyna  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[35] = { 
   intro:['introsone/dujtarakifarjoriintro1.mp3', 
          'introsone/dujtarakifarjoriintro2.mp3',  
          'introsone/dujtarakifarjoriintro3.mp3', 
          'introsone/dujtarakifarjoriintro4.mp3',  
          'introsone/dujtarakifarjoriintro5.mp3', 
          'introsone/dujtarakifarjoriintro6.mp3',  
          'introsone/dujtarakifarjoriintro7.mp3', 
          'introsone/dujtarakifarjoriintro8.mp3',  
          'introsone/dujtarakifarjoriintro9.mp3', 
          'introsone/dujtarakifarjoriintro10.mp3',  
          'introsone/dujtarakifarjoriintro11.mp3'],  
   song:'zulaykhomahmadshoevadukhtarakifarkhori.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Tayikistán (🇹🇯) / interprete: Zulaykho Mahmadshoeva / cancion: Dukhtaraki Farkhori  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[36] = { 
   intro:['introsone/lovemeintro1.mp3', 
          'introsone/lovemeintro2.mp3',  
          'introsone/lovemeintro3.mp3', 
          'introsone/lovemeintro4.mp3',  
          'introsone/lovemeintro5.mp3', 
          'introsone/lovemeintro6.mp3',  
          'introsone/lovemeintro7.mp3', 
          'introsone/lovemeintro8.mp3',  
          'introsone/lovemeintro9.mp3', 
          'introsone/lovemeintro10.mp3',  
          'introsone/lovemeintro11.mp3'],  
   song:'fatimarabadanovaykurbangusaykhanovloveme.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima rabadanova y kurban gusaykhanov / cancion: love me  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[37] = { 
   intro:['introsone/tepegoepaintro1.mp3', 
          'introsone/tepegoepaintro2.mp3', 
          'introsone/tepegoepaintro3.mp3', 
          'introsone/tepegoepaintro4.mp3',  
          'introsone/tepegoepaintro5.mp3', 
          'introsone/tepegoepaintro6.mp3',  
          'introsone/tepegoepaintro7.mp3', 
          'introsone/tepegoepaintro8.mp3',  
          'introsone/tepegoepaintro9.mp3', 
          'introsone/tepegoepaintro10.mp3',  
          'introsone/tepegoepaintro11.mp3'],  
   song:'alexferraritepegoepa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: brasil (🇧🇷) / interprete: alex ferrari / cancion: te pego e pa  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[38] = { 
   intro:['introsone/kisskissintro1.mp3', 
          'introsone/kisskissintro2.mp3', 
          'introsone/kisskissintro3.mp3', 
          'introsone/kisskissintro4.mp3',  
          'introsone/kisskissintro5.mp3', 
          'introsone/kisskissintro6.mp3',  
          'introsone/kisskissintro7.mp3', 
          'introsone/kisskissintro8.mp3',  
          'introsone/kisskissintro9.mp3', 
          'introsone/kisskissintro10.mp3',  
          'introsone/kisskissintro11.mp3'],  
   song:'tarkankisskiss.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: tarkan / cancion: kiss kiss (şimarik)  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }    

 list1[39] = { 
   intro:['introsone/schustermeenamoreintro1.mp3', 
          'introsone/schustermeenamoreintro2.mp3',  
          'introsone/schustermeenamoreintro3.mp3', 
          'introsone/schustermeenamoreintro4.mp3',  
          'introsone/schustermeenamoreintro5.mp3', 
          'introsone/schustermeenamoreintro6.mp3',  
          'introsone/schustermeenamoreintro7.mp3', 
          'introsone/schustermeenamoreintro8.mp3',  
          'introsone/schustermeenamoreintro9.mp3', 
          'introsone/schustermeenamoreintro10.mp3',  
          'introsone/schustermeenamoreintro11.mp3'],  
   song:'augustoschustermeenamore.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: augusto schuster / cancion: me enamore  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[40] = { 
   intro:['introsone/dancingondangerousintro1.mp3', 
          'introsone/dancingondangerousintro2.mp3', 
          'introsone/dancingondangerousintro3.mp3', 
          'introsone/dancingondangerousintro4.mp3',  
          'introsone/dancingondangerousintro5.mp3', 
          'introsone/dancingondangerousintro6.mp3',  
          'introsone/dancingondangerousintro7.mp3', 
          'introsone/dancingondangerousintro8.mp3',  
          'introsone/dancingondangerousintro9.mp3', 
          'introsone/dancingondangerousintro10.mp3',  
          'introsone/dancingondangerousintro11.mp3'],  
   song:'imanbekseanpaulsofiareyesdancingondangerous.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: kazajistan (🇰🇿) - jamaica (🇯🇲) - mexico (🇲🇽) / interprete: imanbek - sean paul - sofia reyes / cancion: dancing on dangerous  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[41] = { 
   intro:['introsone/schusterhastaelamanecerintro1.mp3', 
          'introsone/schusterhastaelamanecerintro2.mp3', 
          'introsone/schusterhastaelamanecerintro3.mp3', 
          'introsone/schusterhastaelamanecerintro4.mp3', 
          'introsone/schusterhastaelamanecerintro5.mp3', 
          'introsone/schusterhastaelamanecerintro6.mp3',  
          'introsone/schusterhastaelamanecerintro7.mp3', 
          'introsone/schusterhastaelamanecerintro8.mp3',  
          'introsone/schusterhastaelamanecerintro9.mp3', 
          'introsone/schusterhastaelamanecerintro10.mp3',  
          'introsone/schusterhastaelamanecerintro11.mp3'],  
   song:'augustoschusterhastaelamanecer.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: augusto schuster / cancion: hasta el amanecer  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[42] = { 
   intro:['introsone/bailamosintro1.mp3', 
          'introsone/bailamosintro2.mp3', 
          'introsone/bailamosintro3.mp3', 
          'introsone/bailamosintro4.mp3',  
          'introsone/bailamosintro5.mp3', 
          'introsone/bailamosintro6.mp3',  
          'introsone/bailamosintro7.mp3', 
          'introsone/bailamosintro8.mp3',  
          'introsone/bailamosintro9.mp3', 
          'introsone/bailamosintro10.mp3',  
          'introsone/bailamosintro11.mp3'],  
   song:'enriqueiglesiasbailamos.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: bailamos  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[43] = { 
   intro:['introsone/unanochemasintro1.mp3', 
          'introsone/unanochemasintro2.mp3', 
          'introsone/unanochemasintro3.mp3', 
          'introsone/unanochemasintro4.mp3',  
          'introsone/unanochemasintro5.mp3', 
          'introsone/unanochemasintro6.mp3',  
          'introsone/unanochemasintro7.mp3', 
          'introsone/unanochemasintro8.mp3',  
          'introsone/unanochemasintro9.mp3', 
          'introsone/unanochemasintro10.mp3',  
          'introsone/unanochemasintro11.mp3'],  
   song:'jenniferlopezunanochemas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: jennifer lopez ( j-lo ) / cancion: una noche mas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[44] = { 
   intro:['introsone/unañosinlluviaintro1.mp3', 
          'introsone/unañosinlluviaintro2.mp3',  
          'introsone/unañosinlluviaintro3.mp3', 
          'introsone/unañosinlluviaintro4.mp3',  
          'introsone/unañosinlluviaintro5.mp3', 
          'introsone/unañosinlluviaintro6.mp3',  
          'introsone/unañosinlluviaintro7.mp3', 
          'introsone/unañosinlluviaintro8.mp3',  
          'introsone/unañosinlluviaintro9.mp3', 
          'introsone/unañosinlluviaintro10.mp3',  
          'introsone/unañosinlluviaintro11.mp3'],  
   song:'selenagomezunanosinlluvia.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: selena gomez / cancion: un año sin lluvia  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[45] = { 
   intro:['introsone/genioatrapadointro1.mp3', 
          'introsone/genioatrapadointro2.mp3', 
          'introsone/genioatrapadointro3.mp3', 
          'introsone/genioatrapadointro4.mp3',  
          'introsone/genioatrapadointro5.mp3', 
          'introsone/genioatrapadointro6.mp3',  
          'introsone/genioatrapadointro7.mp3', 
          'introsone/genioatrapadointro8.mp3',  
          'introsone/genioatrapadointro9.mp3', 
          'introsone/genioatrapadointro10.mp3',  
          'introsone/genioatrapadointro11.mp3'],  
   song:'christinaaguileragenioatrapado.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: christina aguilera / cancion: genio atrapado  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[46] = { 
   intro:['introsone/mienteintro1.mp3', 
          'introsone/mienteintro2.mp3', 
          'introsone/mienteintro3.mp3', 
          'introsone/mienteintro4.mp3',  
          'introsone/mienteintro5.mp3', 
          'introsone/mienteintro6.mp3',  
          'introsone/mienteintro7.mp3', 
          'introsone/mienteintro8.mp3',  
          'introsone/mienteintro9.mp3', 
          'introsone/mienteintro10.mp3',  
          'introsone/mienteintro11.mp3'],  
   song:'enriqueiglesiasmiente.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: miente  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[47] = { 
   intro:['introsone/danceagainintro1.mp3', 
          'introsone/danceagainintro2.mp3', 
          'introsone/danceagainintro3.mp3', 
          'introsone/danceagainintro4.mp3',  
          'introsone/danceagainintro5.mp3', 
          'introsone/danceagainintro6.mp3',  
          'introsone/danceagainintro7.mp3', 
          'introsone/danceagainintro8.mp3',  
          'introsone/danceagainintro9.mp3', 
          'introsone/danceagainintro10.mp3',  
          'introsone/danceagainintro11.mp3'],  
   song:'jenniferlopezypitbulldanceagain.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: jennifer lopez y pitbull / cancion: dance again  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[48] = { 
   intro:['introsone/dimeintro1.mp3', 
          'introsone/dimeintro2.mp3', 
          'introsone/dimeintro3.mp3', 
          'introsone/dimeintro4.mp3',  
          'introsone/dimeintro5.mp3', 
          'introsone/dimeintro6.mp3',  
          'introsone/dimeintro7.mp3', 
          'introsone/dimeintro8.mp3',  
          'introsone/dimeintro9.mp3', 
          'introsone/dimeintro10.mp3',  
          'introsone/dimeintro11.mp3'],  
   song:'karenpaoladime.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: karen paola / cancion: dime  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[49] = { 
   intro:['introsone/summerloveintro1.mp3', 
          'introsone/summerloveintro2.mp3', 
          'introsone/summerloveintro3.mp3', 
          'introsone/summerloveintro4.mp3',  
          'introsone/summerloveintro5.mp3', 
          'introsone/summerloveintro6.mp3',  
          'introsone/summerloveintro7.mp3', 
          'introsone/summerloveintro8.mp3',  
          'introsone/summerloveintro9.mp3', 
          'introsone/summerloveintro10.mp3',  
          'introsone/summerloveintro11.mp3'],  
   song:'karenoliviersummerlove.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: karen olivier / cancion: summer love  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[50] = { 
   intro:['introstwo/nobodylikeyouintro1.mp3', 
          'introstwo/nobodylikeyouintro2.mp3',  
          'introstwo/nobodylikeyouintro3.mp3', 
          'introstwo/nobodylikeyouintro4.mp3',  
          'introstwo/nobodylikeyouintro5.mp3', 
          'introstwo/nobodylikeyouintro6.mp3',  
          'introstwo/nobodylikeyouintro7.mp3', 
          'introstwo/nobodylikeyouintro8.mp3',  
          'introstwo/nobodylikeyouintro9.mp3', 
          'introstwo/nobodylikeyouintro10.mp3',  
          'introstwo/nobodylikeyouintro11.mp3'],  
   song:'francoelgorilayoneillnobodylikeyou.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: puerto rico (🇵🇷) / interprete: franco el gorila y o'neill / cancion: nobody like you   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[51] = { 
   intro:['introstwo/taubataubaintro1.mp3', 
          'introstwo/taubataubaintro2.mp3', 
          'introstwo/taubataubaintro3.mp3', 
          'introstwo/taubataubaintro4.mp3',  
          'introstwo/taubataubaintro5.mp3', 
          'introstwo/taubataubaintro6.mp3',  
          'introstwo/taubataubaintro7.mp3', 
          'introstwo/taubataubaintro8.mp3',  
          'introstwo/taubataubaintro9.mp3', 
          'introstwo/taubataubaintro10.mp3',  
          'introstwo/taubataubaintro11.mp3'],  
   song:'karanaujlataubatauba.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) / interprete: karan aujla / cancion: tauba tauba   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[52] = { 
   intro:['introstwo/laultimatentacionintro1.mp3', 
          'introstwo/laultimatentacionintro2.mp3', 
          'introstwo/laultimatentacionintro3.mp3', 
          'introstwo/laultimatentacionintro4.mp3',  
          'introstwo/laultimatentacionintro5.mp3', 
          'introstwo/laultimatentacionintro6.mp3',  
          'introstwo/laultimatentacionintro7.mp3', 
          'introstwo/laultimatentacionintro8.mp3',  
          'introstwo/laultimatentacionintro9.mp3', 
          'introstwo/laultimatentacionintro10.mp3',  
          'introstwo/laultimatentacionintro11.mp3'],  
   song:'mariajosequintanillaluisjarafrancoelgorilalaultimatentacion.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) - puerto rico (🇵🇷) / interprete: maria jose quintanilla - luis jara - franco el gorila / cancion: la ultima tentacion  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[53] = { 
   intro:['introstwo/meresapnokiraniintro1.mp3', 
          'introstwo/meresapnokiraniintro2.mp3',  
          'introstwo/meresapnokiraniintro3.mp3', 
          'introstwo/meresapnokiraniintro4.mp3',  
          'introstwo/meresapnokiraniintro5.mp3', 
          'introstwo/meresapnokiraniintro6.mp3',  
          'introstwo/meresapnokiraniintro7.mp3', 
          'introstwo/meresapnokiraniintro8.mp3',  
          'introstwo/meresapnokiraniintro9.mp3', 
          'introstwo/meresapnokiraniintro10.mp3',  
          'introstwo/meresapnokiraniintro11.mp3'],  
   song:'tamanabatiadiviakumarmeresapnokirani.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) / interprete: Tamanna Bhatia y Divya Kumar / cancion: mere sapno ki rani  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[54] = { 
   intro:['introstwo/istoriyaintro1.mp3', 
          'introstwo/istoriyaintro2.mp3', 
          'introstwo/istoriyaintro3.mp3', 
          'introstwo/istoriyaintro4.mp3',  
          'introstwo/istoriyaintro5.mp3', 
          'introstwo/istoriyaintro6.mp3',  
          'introstwo/istoriyaintro7.mp3', 
          'introstwo/istoriyaintro8.mp3',  
          'introstwo/istoriyaintro9.mp3', 
          'introstwo/istoriyaintro10.mp3',  
          'introstwo/istoriyaintro11.mp3'],  
   song:'myroistoriya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: MY-RO / cancion: istoriya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[55] = { 
   intro:['introstwo/jiumengintro1.mp3', 
          'introstwo/jiumengintro2.mp3', 
          'introstwo/jiumengintro3.mp3', 
          'introstwo/jiumengintro4.mp3',  
          'introstwo/jiumengintro5.mp3', 
          'introstwo/jiumengintro6.mp3',  
          'introstwo/jiumengintro7.mp3', 
          'introstwo/jiumengintro8.mp3',  
          'introstwo/jiumengintro9.mp3', 
          'introstwo/jiumengintro10.mp3',  
          'introstwo/jiumengintro11.mp3'],  
   song:'tongxinjiumeng.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: tong xin / cancion: jiu meng (dj version)  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[56] = { 
   intro:['introstwo/avishnyakrasnayaintro1.mp3', 
          'introstwo/avishnyakrasnayaintro2.mp3', 
          'introstwo/avishnyakrasnayaintro3.mp3', 
          'introstwo/avishnyakrasnayaintro4.mp3',  
          'introstwo/avishnyakrasnayaintro5.mp3', 
          'introstwo/avishnyakrasnayaintro6.mp3',  
          'introstwo/avishnyakrasnayaintro7.mp3', 
          'introstwo/avishnyakrasnayaintro8.mp3',  
          'introstwo/avishnyakrasnayaintro9.mp3', 
          'introstwo/avishnyakrasnayaintro10.mp3',  
          'introstwo/avishnyakrasnayaintro11.mp3'],  
   song:'kristinasokolovaavishnyakrasnaya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: kristina sokolova / cancion: a vishnya krasnaya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[57] = { 
   intro:['introstwo/nabelompokryvaleyanvaryaintro1.mp3', 
          'introstwo/nabelompokryvaleyanvaryaintro2.mp3',  
          'introstwo/nabelompokryvaleyanvaryaintro3.mp3', 
          'introstwo/nabelompokryvaleyanvaryaintro4.mp3',  
          'introstwo/nabelompokryvaleyanvaryaintro5.mp3', 
          'introstwo/nabelompokryvaleyanvaryaintro6.mp3',  
          'introstwo/nabelompokryvaleyanvaryaintro7.mp3', 
          'introstwo/nabelompokryvaleyanvaryaintro8.mp3',  
          'introstwo/nabelompokryvaleyanvaryaintro9.mp3', 
          'introstwo/nabelompokryvaleyanvaryaintro10.mp3',  
          'introstwo/nabelompokryvaleyanvaryaintro11.mp3'],  
   song:'kamazznabelompokryvaleyanvarya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: kamazz / cancion: na belom pokryvale yanvarya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[58] = { 
   intro:['introstwo/nidedaanintro1.mp3', 
          'introstwo/nidedaanintro2.mp3', 
          'introstwo/nidedaanintro3.mp3', 
          'introstwo/nidedaanintro4.mp3',  
          'introstwo/nidedaanintro5.mp3', 
          'introstwo/nidedaanintro6.mp3',  
          'introstwo/nidedaanintro7.mp3', 
          'introstwo/nidedaanintro8.mp3',  
          'introstwo/nidedaanintro9.mp3', 
          'introstwo/nidedaanintro10.mp3',  
          'introstwo/nidedaanintro11.mp3'],  
   song:'ziyaonidedaan.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: zǐ yáo / cancion: Nǐ de dá'àn  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[59] = { 
   intro:['introstwo/oistamamintro1.mp3', 
          'introstwo/oistamamintro2.mp3', 
          'introstwo/oistamamintro3.mp3', 
          'introstwo/oistamamintro4.mp3',  
          'introstwo/oistamamintro5.mp3', 
          'introstwo/oistamamintro6.mp3',  
          'introstwo/oistamamintro7.mp3', 
          'introstwo/oistamamintro8.mp3',  
          'introstwo/oistamamintro9.mp3', 
          'introstwo/oistamamintro10.mp3',  
          'introstwo/oistamamintro11.mp3'],  
   song:'mumtazatesoistamam.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: mümtaz ateş / cancion: o iş tamam &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[60] = { 
   intro:['introstwo/keerintro1.mp3', 
          'introstwo/keerintro2.mp3', 
          'introstwo/keerintro3.mp3', 
          'introstwo/keerintro4.mp3',  
          'introstwo/keerintro5.mp3', 
          'introstwo/keerintro6.mp3',  
          'introstwo/keerintro7.mp3', 
          'introstwo/keerintro8.mp3',  
          'introstwo/keerintro9.mp3', 
          'introstwo/keerintro10.mp3',  
          'introstwo/keerintro11.mp3'],  
   song:'chinchiuchekeer.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: jīnjiǔ zhé / cancion: Kē er  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[61] = { 
   intro:['introstwo/echamelaculpaintro1.mp3', 
          'introstwo/echamelaculpaintro2.mp3',  
          'introstwo/echamelaculpaintro3.mp3', 
          'introstwo/echamelaculpaintro4.mp3',  
          'introstwo/echamelaculpaintro5.mp3', 
          'introstwo/echamelaculpaintro6.mp3',  
          'introstwo/echamelaculpaintro7.mp3', 
          'introstwo/echamelaculpaintro8.mp3',  
          'introstwo/echamelaculpaintro9.mp3', 
          'introstwo/echamelaculpaintro10.mp3',  
          'introstwo/echamelaculpaintro11.mp3'],  
   song:'luisfonsiydemilovatoechamelaculpa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: puerto rico (🇵🇷) - estados unidos (🇺🇸) / interprete: luis fonsi y demi lovato / cancion: echame la culpa  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[62] = { 
   intro:['introstwo/glowenosdogoryintro1.mp3',  
          'introstwo/glowenosdogoryintro2.mp3', 
          'introstwo/glowenosdogoryintro3.mp3',  
          'introstwo/glowenosdogoryintro4.mp3',  
          'introstwo/glowenosdogoryintro5.mp3',  
          'introstwo/glowenosdogoryintro6.mp3',  
          'introstwo/glowenosdogoryintro7.mp3',  
          'introstwo/glowenosdogoryintro8.mp3',  
          'introstwo/glowenosdogoryintro9.mp3',  
          'introstwo/glowenosdogoryintro10.mp3',  
          'introstwo/glowenosdogoryintro11.mp3', 
          'introstwo/glowenosdogoryintro12.mp3',  
          'introstwo/glowenosdogoryintro13.mp3',  
          'introstwo/glowenosdogoryintro14.mp3',  
          'introstwo/glowenosdogoryintro15.mp3'],  
   song:'pectuskasiacerekwickaglowenosdogory.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: polonia (🇵🇱) / interpretes: pectus & Kasia Cerekwicka / cancion: Głowę noś do góry   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[63] = { 
   intro:['introstwo/ritmototalintro1.mp3',  
          'introstwo/ritmototalintro2.mp3', 
          'introstwo/ritmototalintro3.mp3',  
          'introstwo/ritmototalintro4.mp3',  
          'introstwo/ritmototalintro5.mp3',  
          'introstwo/ritmototalintro6.mp3',  
          'introstwo/ritmototalintro7.mp3',  
          'introstwo/ritmototalintro8.mp3',  
          'introstwo/ritmototalintro9.mp3',  
          'introstwo/ritmototalintro10.mp3',  
          'introstwo/ritmototalintro11.mp3'],  
   song:'enriqueiglesiasritmototal.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: ritmo total   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[64] = { 
   intro:['introstwo/chtochtylyetaintro1.mp3',  
          'introstwo/chtochtylyetaintro2.mp3', 
          'introstwo/chtochtylyetaintro3.mp3',  
          'introstwo/chtochtylyetaintro4.mp3',  
          'introstwo/chtochtylyetaintro5.mp3',  
          'introstwo/chtochtylyetaintro6.mp3',  
          'introstwo/chtochtylyetaintro7.mp3',  
          'introstwo/chtochtylyetaintro8.mp3',  
          'introstwo/chtochtylyetaintro9.mp3',  
          'introstwo/chtochtylyetaintro10.mp3',  
          'introstwo/chtochtylyetaintro11.mp3'],  
   song:'yekaterinadenisovachtochtylyeta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: Yekaterina Denisova / cancion: Chto zh ty lyeta   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[65] = { 
   intro:['introstwo/tejocicuminteameaintro1.mp3',  
          'introstwo/tejocicuminteameaintro2.mp3',  
          'introstwo/tejocicuminteameaintro3.mp3',  
          'introstwo/tejocicuminteameaintro4.mp3',  
          'introstwo/tejocicuminteameaintro5.mp3',  
          'introstwo/tejocicuminteameaintro6.mp3',  
          'introstwo/tejocicuminteameaintro7.mp3',  
          'introstwo/tejocicuminteameaintro8.mp3',  
          'introstwo/tejocicuminteameaintro9.mp3',  
          'introstwo/tejocicuminteameaintro10.mp3',  
          'introstwo/tejocicuminteameaintro11.mp3'],  
   song:'sandranmariusnedelcutejocicuminteamea.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: Sandra N. feat. Marius Nedelcu / cancion: Te joci cu mintea mea   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[66] = { 
   intro:['introstwo/introziintro1.mp3',  
          'introstwo/introziintro2.mp3', 
          'introstwo/introziintro3.mp3',  
          'introstwo/introziintro4.mp3',  
          'introstwo/introziintro5.mp3',  
          'introstwo/introziintro6.mp3',  
          'introstwo/introziintro7.mp3',  
          'introstwo/introziintro8.mp3',  
          'introstwo/introziintro9.mp3',  
          'introstwo/introziintro10.mp3',  
          'introstwo/introziintro11.mp3'],  
   song:'valentindinuanyaintrozi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: valentin dinu y anya / cancion: intr-o zi   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[67] = { 
   intro:['introstwo/ludanocintro1.mp3', 
          'introstwo/ludanocintro2.mp3',   
          'introstwo/ludanocintro3.mp3',   
          'introstwo/ludanocintro4.mp3',    
          'introstwo/ludanocintro5.mp3',    
          'introstwo/ludanocintro6.mp3',    
          'introstwo/ludanocintro7.mp3',    
          'introstwo/ludanocintro8.mp3',    
          'introstwo/ludanocintro9.mp3',   
          'introstwo/ludanocintro10.mp3',    
          'introstwo/ludanocintro11.mp3',    
          'introstwo/ludanocintro12.mp3',    
          'introstwo/ludanocintro13.mp3',    
          'introstwo/ludanocintro14.mp3',    
          'introstwo/ludanocintro15.mp3' ],    
   song:'nikaludanoc.mp3',   
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Serbia (🇷🇸) / interprete: Nika / cancion: Luda Noć (Crazy Night)  &nbsp&nbsp&nbsp&#160&#160&#160"   
 }  

 list1[68] = { 
   intro:['introstwo/pananzoriintro1.mp3',  
          'introstwo/pananzoriintro2.mp3', 
          'introstwo/pananzoriintro3.mp3',  
          'introstwo/pananzoriintro4.mp3',  
          'introstwo/pananzoriintro5.mp3',  
          'introstwo/pananzoriintro6.mp3',  
          'introstwo/pananzoriintro7.mp3',  
          'introstwo/pananzoriintro8.mp3',  
          'introstwo/pananzoriintro9.mp3',  
          'introstwo/pananzoriintro10.mp3',  
          'introstwo/pananzoriintro11.mp3'],  
   song:'vasilemacoveipananzori.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: moldavia (🇲🇩) / interprete: vasile macovei / cancion: Până-n zori   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[69] = { 
   intro:['introstwo/amanamanintro1.mp3',  
          'introstwo/amanamanintro2.mp3', 
          'introstwo/amanamanintro3.mp3',  
          'introstwo/amanamanintro4.mp3',  
          'introstwo/amanamanintro5.mp3',  
          'introstwo/amanamanintro6.mp3',  
          'introstwo/amanamanintro7.mp3',  
          'introstwo/amanamanintro8.mp3',  
          'introstwo/amanamanintro9.mp3',  
          'introstwo/amanamanintro10.mp3',  
          'introstwo/amanamanintro11.mp3'],  
   song:'eldaramanaman.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: eldar / cancion: Aman-Aman  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[70] = { 
   intro:['introstwo/guelmeneintro1.mp3',  
          'introstwo/guelmeneintro2.mp3', 
          'introstwo/guelmeneintro3.mp3',  
          'introstwo/guelmeneintro4.mp3',  
          'introstwo/guelmeneintro5.mp3',  
          'introstwo/guelmeneintro6.mp3',  
          'introstwo/guelmeneintro7.mp3',  
          'introstwo/guelmeneintro8.mp3',  
          'introstwo/guelmeneintro9.mp3',  
          'introstwo/guelmeneintro10.mp3',  
          'introstwo/guelmeneintro11.mp3'],  
   song:'sevdayahyayevagelmene.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: Sevda Yahyayeva / cancion: Gəl Mənə  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[71] = { 
   intro:['introstwo/seviramintro1.mp3',  
          'introstwo/seviramintro2.mp3', 
          'introstwo/seviramintro3.mp3',  
          'introstwo/seviramintro4.mp3',  
          'introstwo/seviramintro5.mp3',  
          'introstwo/seviramintro6.mp3',  
          'introstwo/seviramintro7.mp3',  
          'introstwo/seviramintro8.mp3',  
          'introstwo/seviramintro9.mp3',  
          'introstwo/seviramintro10.mp3',  
          'introstwo/seviramintro11.mp3'],  
   song:'miriyusifseviram.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: miri yusif / cancion: Sevirəm  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[72] = { 
   intro:['introstwo/kameliaintro1.mp3',  
          'introstwo/kameliaintro2.mp3', 
          'introstwo/kameliaintro3.mp3',  
          'introstwo/kameliaintro4.mp3',  
          'introstwo/kameliaintro5.mp3',  
          'introstwo/kameliaintro6.mp3',  
          'introstwo/kameliaintro7.mp3',  
          'introstwo/kameliaintro8.mp3',  
          'introstwo/kameliaintro9.mp3',  
          'introstwo/kameliaintro10.mp3',  
          'introstwo/kameliaintro11.mp3'],  
   song:'akcentlidiabubleddynuneskamelia.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Rumania (🇷🇴) - Brasil (🇧🇷) / interprete: akcent con lidia buble y ddy nunes / cancion: Kamelia  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[73] = { 
   intro:['introstwo/miloyavointro1.mp3',  
          'introstwo/miloyavointro2.mp3',  
          'introstwo/miloyavointro3.mp3',  
          'introstwo/miloyavointro4.mp3',  
          'introstwo/miloyavointro5.mp3',  
          'introstwo/miloyavointro6.mp3',  
          'introstwo/miloyavointro7.mp3',  
          'introstwo/miloyavointro8.mp3',  
          'introstwo/miloyavointro9.mp3',  
          'introstwo/miloyavointro10.mp3',  
          'introstwo/miloyavointro11.mp3'],  
   song:'avrahamtalbenaiabarabimiloyavo.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: Avraham Tal y Benaia Barabi / cancion: mi lo yavo  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[74] = { 
   intro:['introstwo/bonadliktaeshintro1.mp3',  
          'introstwo/bonadliktaeshintro2.mp3',  
          'introstwo/bonadliktaeshintro3.mp3',  
          'introstwo/bonadliktaeshintro4.mp3',  
          'introstwo/bonadliktaeshintro5.mp3',  
          'introstwo/bonadliktaeshintro6.mp3',  
          'introstwo/bonadliktaeshintro7.mp3',  
          'introstwo/bonadliktaeshintro8.mp3',  
          'introstwo/bonadliktaeshintro9.mp3',  
          'introstwo/bonadliktaeshintro10.mp3',  
          'introstwo/bonadliktaeshintro11.mp3'],  
   song:'itzikorlevbonadliktaesh.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: itzik orlev / cancion: bo nadlik t'esh  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[75] = { 
   intro:['introstwo/majshavottovotintro1.mp3',  
          'introstwo/majshavottovotintro2.mp3',  
          'introstwo/majshavottovotintro3.mp3',  
          'introstwo/majshavottovotintro4.mp3',  
          'introstwo/majshavottovotintro5.mp3',  
          'introstwo/majshavottovotintro6.mp3',  
          'introstwo/majshavottovotintro7.mp3',  
          'introstwo/majshavottovotintro8.mp3',  
          'introstwo/majshavottovotintro9.mp3',  
          'introstwo/majshavottovotintro10.mp3',  
          'introstwo/majshavottovotintro11.mp3'],  
   song:'motiweissmachshavottovot.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: motty weiss / cancion: Machshavot Tovot  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[76] = { 
   intro:['introstwo/yamaintro1.mp3',  
          'introstwo/yamaintro2.mp3',  
          'introstwo/yamaintro3.mp3',  
          'introstwo/yamaintro4.mp3',  
          'introstwo/yamaintro5.mp3',  
          'introstwo/yamaintro6.mp3',  
          'introstwo/yamaintro7.mp3',  
          'introstwo/yamaintro8.mp3',  
          'introstwo/yamaintro9.mp3',  
          'introstwo/yamaintro10.mp3',  
          'introstwo/yamaintro11.mp3'],  
   song:'bennyfriedmanyama.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: benny friedman / cancion: YAMA  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[77] = { 
   intro:['introstwo/sanavaguiintro1.mp3',  
          'introstwo/sanavaguiintro2.mp3', 
          'introstwo/sanavaguiintro3.mp3',  
          'introstwo/sanavaguiintro4.mp3',  
          'introstwo/sanavaguiintro5.mp3',  
          'introstwo/sanavaguiintro6.mp3',  
          'introstwo/sanavaguiintro7.mp3',  
          'introstwo/sanavaguiintro8.mp3',  
          'introstwo/sanavaguiintro9.mp3',  
          'introstwo/sanavaguiintro10.mp3',  
          'introstwo/sanavaguiintro11.mp3'],  
   song:'ninosanavagui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: nino / cancion: sa navagi  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[78] = { 
   intro:['introstwo/theosintro1.mp3',  
          'introstwo/theosintro2.mp3', 
          'introstwo/theosintro3.mp3',  
          'introstwo/theosintro4.mp3',  
          'introstwo/theosintro5.mp3',  
          'introstwo/theosintro6.mp3',  
          'introstwo/theosintro7.mp3',  
          'introstwo/theosintro8.mp3',  
          'introstwo/theosintro9.mp3',  
          'introstwo/theosintro10.mp3',  
          'introstwo/theosintro11.mp3'],  
   song:'ninotheos.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: nino / cancion: theos  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[79] = { 
   intro:['introstwo/dodnaintro1.mp3',  
          'introstwo/dodnaintro2.mp3', 
          'introstwo/dodnaintro3.mp3',  
          'introstwo/dodnaintro4.mp3',  
          'introstwo/dodnaintro5.mp3',  
          'introstwo/dodnaintro6.mp3',  
          'introstwo/dodnaintro7.mp3',  
          'introstwo/dodnaintro8.mp3',  
          'introstwo/dodnaintro9.mp3',  
          'introstwo/dodnaintro10.mp3',  
          'introstwo/dodnaintro11.mp3'],  
   song:'oksananasanovichdodna.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bielorrusia (🇧🇾) / interprete: oksana nasanovich / cancion: do dna  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[80] = { 
   intro:['introstwo/paointro1.mp3',  
          'introstwo/paointro2.mp3', 
          'introstwo/paointro3.mp3',  
          'introstwo/paointro4.mp3',  
          'introstwo/paointro5.mp3',  
          'introstwo/paointro6.mp3',  
          'introstwo/paointro7.mp3',  
          'introstwo/paointro8.mp3', 
          'introstwo/paointro9.mp3',  
          'introstwo/paointro10.mp3',  
          'introstwo/paointro11.mp3'],  
   song:'iviadamoukonniemetaxapao.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: ívi adámou y konnie metaxa / cancion: páo  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[81] = { 
   intro:['introstwo/opoumepasintro1.mp3',  
          'introstwo/opoumepasintro2.mp3', 
          'introstwo/opoumepasintro3.mp3',  
          'introstwo/opoumepasintro4.mp3',  
          'introstwo/opoumepasintro5.mp3',  
          'introstwo/opoumepasintro6.mp3',  
          'introstwo/opoumepasintro7.mp3',  
          'introstwo/opoumepasintro8.mp3', 
          'introstwo/opoumepasintro9.mp3',  
          'introstwo/opoumepasintro10.mp3',  
          'introstwo/opoumepasintro11.mp3'],  
   song:'kingsantonellaopoumepas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: kings y antonella / cancion: opou me pas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[82] = { 
   intro:['introstwo/dyozoesintro1.mp3',  
          'introstwo/dyozoesintro2.mp3', 
          'introstwo/dyozoesintro3.mp3',  
          'introstwo/dyozoesintro4.mp3',  
          'introstwo/dyozoesintro5.mp3',  
          'introstwo/dyozoesintro6.mp3',  
          'introstwo/dyozoesintro7.mp3',  
          'introstwo/dyozoesintro8.mp3', 
          'introstwo/dyozoesintro9.mp3',  
          'introstwo/dyozoesintro10.mp3',  
          'introstwo/dyozoesintro11.mp3'],  
   song:'kingsantonelladyozoes.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: kings y Antonella / cancion: dyo zoes  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[83] = { 
   intro:['introstwo/giatimetyrannasintro1.mp3',  
          'introstwo/giatimetyrannasintro2.mp3', 
          'introstwo/giatimetyrannasintro3.mp3',  
          'introstwo/giatimetyrannasintro4.mp3',  
          'introstwo/giatimetyrannasintro5.mp3',  
          'introstwo/giatimetyrannasintro6.mp3',  
          'introstwo/giatimetyrannasintro7.mp3',  
          'introstwo/giatimetyrannasintro8.mp3', 
          'introstwo/giatimetyrannasintro9.mp3',  
          'introstwo/giatimetyrannasintro10.mp3',  
          'introstwo/giatimetyrannasintro11.mp3'],  
   song:'dimitriskokotasgiatimetyrannas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: Dimítris Kókotas / cancion: Giatí Me Tyrannás  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[84] = { 
   intro:['introstwo/byagayintro1.mp3',  
          'introstwo/byagayintro2.mp3', 
          'introstwo/byagayintro3.mp3',  
          'introstwo/byagayintro4.mp3',  
          'introstwo/byagayintro5.mp3',  
          'introstwo/byagayintro6.mp3',  
          'introstwo/byagayintro7.mp3',  
          'introstwo/byagayintro8.mp3', 
          'introstwo/byagayintro9.mp3',  
          'introstwo/byagayintro10.mp3',  
          'introstwo/byagayintro11.mp3'],  
   song:'slavigumzatakukubandbyagay.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Slavi, Gumzata & Ku-Ku Band / cancion: Byagay  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[85] = { 
   intro:['introstwo/oshteintro1.mp3',  
          'introstwo/oshteintro2.mp3', 
          'introstwo/oshteintro3.mp3',  
          'introstwo/oshteintro4.mp3',  
          'introstwo/oshteintro5.mp3',  
          'introstwo/oshteintro6.mp3',  
          'introstwo/oshteintro7.mp3',  
          'introstwo/oshteintro8.mp3', 
          'introstwo/oshteintro9.mp3',  
          'introstwo/oshteintro10.mp3',  
          'introstwo/oshteintro11.mp3'],  
   song:'vanesaoshte.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: vanesa / cancion: oshte  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[86] = { 
   intro:['introstwo/nainatintro1.mp3',  
          'introstwo/nainatintro2.mp3', 
          'introstwo/nainatintro3.mp3',  
          'introstwo/nainatintro4.mp3',  
          'introstwo/nainatintro5.mp3',  
          'introstwo/nainatintro6.mp3',  
          'introstwo/nainatintro7.mp3',  
          'introstwo/nainatintro8.mp3', 
          'introstwo/nainatintro9.mp3',  
          'introstwo/nainatintro10.mp3',  
          'introstwo/nainatintro11.mp3',  
          'introstwo/nainatintro12.mp3'],  
   song:'poligenovanainat.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Poli Genova / cancion: Na Inat  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[87] = { 
   intro:['introstwo/samotiintro1.mp3',  
          'introstwo/samotiintro2.mp3', 
          'introstwo/samotiintro3.mp3',  
          'introstwo/samotiintro4.mp3',  
          'introstwo/samotiintro5.mp3',  
          'introstwo/samotiintro6.mp3',  
          'introstwo/samotiintro7.mp3',  
          'introstwo/samotiintro8.mp3', 
          'introstwo/samotiintro9.mp3',  
          'introstwo/samotiintro10.mp3',  
          'introstwo/samotiintro11.mp3',  
          'introstwo/samotiintro12.mp3'],  
   song:'lazarsamoti.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Lazar / cancion: Samo Ti  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[88] = { 
   intro:['introstwo/dokraiintro1.mp3',  
          'introstwo/dokraiintro2.mp3', 
          'introstwo/dokraiintro3.mp3',  
          'introstwo/dokraiintro4.mp3',  
          'introstwo/dokraiintro5.mp3',  
          'introstwo/dokraiintro6.mp3',  
          'introstwo/dokraiintro7.mp3',  
          'introstwo/dokraiintro8.mp3', 
          'introstwo/dokraiintro9.mp3',  
          'introstwo/dokraiintro10.mp3',  
          'introstwo/dokraiintro11.mp3',  
          'introstwo/dokraiintro12.mp3'],  
   song:'andreadokrai.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: ANDREA / cancion: Dokrai &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[89] = { 
   intro:['introstwo/noshttagarmiintro1.mp3',  
          'introstwo/noshttagarmiintro2.mp3', 
          'introstwo/noshttagarmiintro3.mp3',  
          'introstwo/noshttagarmiintro4.mp3',  
          'introstwo/noshttagarmiintro5.mp3',  
          'introstwo/noshttagarmiintro6.mp3',  
          'introstwo/noshttagarmiintro7.mp3',  
          'introstwo/noshttagarmiintro8.mp3', 
          'introstwo/noshttagarmiintro9.mp3',  
          'introstwo/noshttagarmiintro10.mp3',  
          'introstwo/noshttagarmiintro11.mp3',  
          'introstwo/noshttagarmiintro12.mp3'],  
   song:'galinlorenanoshttagarmi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Galin & Lorena / cancion: NOSHTTA GARMI   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[90] = { 
   intro:['introstwo/pecsaulesrietaintro1.mp3',  
          'introstwo/pecsaulesrietaintro2.mp3', 
          'introstwo/pecsaulesrietaintro3.mp3',  
          'introstwo/pecsaulesrietaintro4.mp3',  
          'introstwo/pecsaulesrietaintro5.mp3',  
          'introstwo/pecsaulesrietaintro6.mp3',  
          'introstwo/pecsaulesrietaintro7.mp3',  
          'introstwo/pecsaulesrietaintro8.mp3', 
          'introstwo/pecsaulesrietaintro9.mp3',  
          'introstwo/pecsaulesrietaintro10.mp3',  
          'introstwo/pecsaulesrietaintro11.mp3',  
          'introstwo/pecsaulesrietaintro12.mp3'],  
   song:'denijsgriezenikolajspuzikovspecsaulesrieta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Denijs Grieze y Nikolajs Puzikovs / cancion: Pēc saules rieta  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[91] = { 
   intro:['introstwo/garigaisariintro1.mp3',  
          'introstwo/garigaisariintro2.mp3', 
          'introstwo/garigaisariintro3.mp3',  
          'introstwo/garigaisariintro4.mp3',  
          'introstwo/garigaisariintro5.mp3',  
          'introstwo/garigaisariintro6.mp3',  
          'introstwo/garigaisariintro7.mp3',  
          'introstwo/garigaisariintro8.mp3', 
          'introstwo/garigaisariintro9.mp3',  
          'introstwo/garigaisariintro10.mp3',  
          'introstwo/garigaisariintro11.mp3',  
          'introstwo/garigaisariintro12.mp3'],  
   song:'musiqqgarigaisari.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: musiqq (Marats Ogļezņevs y Emīls Balceris) / cancion: Garīgais arī   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[92] = { 
   intro:['introstwo/muzikaplustpavenamintro1.mp3',  
          'introstwo/muzikaplustpavenamintro2.mp3', 
          'introstwo/muzikaplustpavenamintro3.mp3',  
          'introstwo/muzikaplustpavenamintro4.mp3',  
          'introstwo/muzikaplustpavenamintro5.mp3',  
          'introstwo/muzikaplustpavenamintro6.mp3',  
          'introstwo/muzikaplustpavenamintro7.mp3',  
          'introstwo/muzikaplustpavenamintro8.mp3', 
          'introstwo/muzikaplustpavenamintro9.mp3',  
          'introstwo/muzikaplustpavenamintro10.mp3',  
          'introstwo/muzikaplustpavenamintro11.mp3',  
          'introstwo/muzikaplustpavenamintro12.mp3'],  
   song:'musiqqmuzikaplustpavenam.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: musiqq (Marats Ogļezņevs y Emīls Balceris) / cancion: Mūzika Plūst Pa Vēnām   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[93] = { 
   intro:['introstwo/mannesanakintro1.mp3',  
          'introstwo/mannesanakintro2.mp3', 
          'introstwo/mannesanakintro3.mp3',  
          'introstwo/mannesanakintro4.mp3',  
          'introstwo/mannesanakintro5.mp3',  
          'introstwo/mannesanakintro6.mp3',  
          'introstwo/mannesanakintro7.mp3',  
          'introstwo/mannesanakintro8.mp3', 
          'introstwo/mannesanakintro9.mp3',  
          'introstwo/mannesanakintro10.mp3',  
          'introstwo/mannesanakintro11.mp3',  
          'introstwo/mannesanakintro12.mp3',  
          'introstwo/mannesanakintro13.mp3',  
          'introstwo/mannesanakintro14.mp3' ],  
   song:'markusrivasamantatinamannesanak.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: MARKUS RIVA y SAMANTA TĪNA / cancion: MAN NESANĀK &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[94] = { 
   intro:['introstwo/vinasvaraintro1.mp3',  
          'introstwo/vinasvaraintro2.mp3', 
          'introstwo/vinasvaraintro3.mp3',  
          'introstwo/vinasvaraintro4.mp3',  
          'introstwo/vinasvaraintro5.mp3',  
          'introstwo/vinasvaraintro6.mp3',  
          'introstwo/vinasvaraintro7.mp3',  
          'introstwo/vinasvaraintro8.mp3', 
          'introstwo/vinasvaraintro9.mp3',  
          'introstwo/vinasvaraintro10.mp3',  
          'introstwo/vinasvaraintro11.mp3',  
          'introstwo/vinasvaraintro12.mp3',  
          'introstwo/vinasvaraintro13.mp3',  
          'introstwo/vinasvaraintro14.mp3' ],  
   song:'dweennikolajspuzikovsmixtypervinasvara.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Dween & Nikolajs Puzikovs pied. Mixtyper / cancion: Viņas varā &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[95] = { 
   intro:['introstwo/tuesikarstaintro1.mp3',  
          'introstwo/tuesikarstaintro2.mp3', 
          'introstwo/tuesikarstaintro3.mp3',  
          'introstwo/tuesikarstaintro4.mp3',  
          'introstwo/tuesikarstaintro5.mp3',  
          'introstwo/tuesikarstaintro6.mp3',  
          'introstwo/tuesikarstaintro7.mp3',  
          'introstwo/tuesikarstaintro8.mp3', 
          'introstwo/tuesikarstaintro9.mp3',  
          'introstwo/tuesikarstaintro10.mp3',  
          'introstwo/tuesikarstaintro11.mp3',  
          'introstwo/tuesikarstaintro12.mp3',  
          'introstwo/tuesikarstaintro13.mp3',  
          'introstwo/tuesikarstaintro14.mp3' ],  
   song:'dweennikolajspuzikovstuesikarsta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Dween un Nikolajs Puzikovs / cancion: Tu esi karsta &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[96] = { 
   intro:['introstwo/netilistigaintro1.mp3',  
          'introstwo/netilistigaintro2.mp3', 
          'introstwo/netilistigaintro3.mp3',  
          'introstwo/netilistigaintro4.mp3',  
          'introstwo/netilistigaintro5.mp3',  
          'introstwo/netilistigaintro6.mp3',  
          'introstwo/netilistigaintro7.mp3',  
          'introstwo/netilistigaintro8.mp3', 
          'introstwo/netilistigaintro9.mp3',  
          'introstwo/netilistigaintro10.mp3',  
          'introstwo/netilistigaintro11.mp3',  
          'introstwo/netilistigaintro12.mp3',  
          'introstwo/netilistigaintro13.mp3',  
          'introstwo/netilistigaintro14.mp3' ],  
   song:'mihaelamarinovanetilistiga.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Mihaela Marinova / cancion: ne ti li stiga  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[97] = { 
   intro:['introstwo/napasintro1.mp3',  
          'introstwo/napasintro2.mp3', 
          'introstwo/napasintro3.mp3',  
          'introstwo/napasintro4.mp3',  
          'introstwo/napasintro5.mp3',  
          'introstwo/napasintro6.mp3',  
          'introstwo/napasintro7.mp3',  
          'introstwo/napasintro8.mp3', 
          'introstwo/napasintro9.mp3',  
          'introstwo/napasintro10.mp3',  
          'introstwo/napasintro11.mp3',  
          'introstwo/napasintro12.mp3',  
          'introstwo/napasintro13.mp3',  
          'introstwo/napasintro14.mp3' ],  
   song:'konstatinosgalanosnapas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: Konstantinos Galanos / cancion: na pas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[98] = { 
   intro:['introstwo/vradiaaksimerotaintro1.mp3',  
          'introstwo/vradiaaksimerotaintro2.mp3', 
          'introstwo/vradiaaksimerotaintro3.mp3',  
          'introstwo/vradiaaksimerotaintro4.mp3',  
          'introstwo/vradiaaksimerotaintro5.mp3',  
          'introstwo/vradiaaksimerotaintro6.mp3',  
          'introstwo/vradiaaksimerotaintro7.mp3',  
          'introstwo/vradiaaksimerotaintro8.mp3', 
          'introstwo/vradiaaksimerotaintro9.mp3',  
          'introstwo/vradiaaksimerotaintro10.mp3',  
          'introstwo/vradiaaksimerotaintro11.mp3',  
          'introstwo/vradiaaksimerotaintro12.mp3',  
          'introstwo/vradiaaksimerotaintro13.mp3',  
          'introstwo/vradiaaksimerotaintro14.mp3' ],  
   song:'petrosiakovidisvradiaaksimerota.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: petros iakovidis / cancion: Vrádia Aksimérota   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[99] = { 
   intro:['introstwo/pecarareamuntilorintro1.mp3',  
          'introstwo/pecarareamuntilorintro2.mp3', 
          'introstwo/pecarareamuntilorintro3.mp3',  
          'introstwo/pecarareamuntilorintro4.mp3',  
          'introstwo/pecarareamuntilorintro5.mp3',  
          'introstwo/pecarareamuntilorintro6.mp3',  
          'introstwo/pecarareamuntilorintro7.mp3',  
          'introstwo/pecarareamuntilorintro8.mp3', 
          'introstwo/pecarareamuntilorintro9.mp3',  
          'introstwo/pecarareamuntilorintro10.mp3',  
          'introstwo/pecarareamuntilorintro11.mp3',  
          'introstwo/pecarareamuntilorintro12.mp3',  
          'introstwo/pecarareamuntilorintro13.mp3',  
          'introstwo/pecarareamuntilorintro14.mp3' ],  
   song:'sandranpecarareamuntilor.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Rumania (🇷🇴) / interprete: Sandra N / cancion: pe cararea muntilor   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  
 
