
// Importamos la API de Audio
const audio = document.getElementById('reproductor');

async function loadbyfetch(){
  const r = await fetch('https://leonardosotelo89.github.io/functional_radioshow_archive2/songs200to299/worldhitamorenlanoche.mp3');
  console.log(r)
  const blob = await r.blob();
  const url = URL.createObjectURL(blob);
  audio.src = url;
  //audio.play(); // si querés que arranque solo requiere user gesture 
}

document.body.onload = loadbyfetch;
//audio.src = 'https://leonardosotelo89.github.io/functional_radioshow_archive2/songs200to299/worldhitamorenlanoche.mp3'

// Event listeners para controlar el reproductor
audio.addEventListener('play', function() {
    console.log('Audio está reproduciendo...');
});

audio.addEventListener('pause', function() {
    console.log('Audio está pausado...');
});

audio.addEventListener('ended', function() {
    console.log('Audio ha finalizado...');
});

audio.addEventListener('load', function() {
    console.log('Audio ha cargado...');
});

// Obtenemos la duración del audio
audio.addEventListener('loadedmetadata', function() {
    const duracion = audio.duration;
    console.log(`Duración del audio: ${duracion} segundos`);
});

// Botones de control para reproducir y pausar
const playButton = document.createElement('button');
playButton.textContent = 'Reproducir';
playButton.addEventListener('click', function() {
    audio.play();
});

const pauseButton = document.createElement('button');
pauseButton.textContent = 'Pausar';
pauseButton.addEventListener('click', function() {
    audio.pause();
});

// Agregamos los botones de forma dinámica
const main = document.querySelector('main');
main.appendChild(playButton);
main.appendChild(pauseButton);



/*
Este ejemplo es básico, pero puede ser personalizado y ampliado para incluir características adicionales como control de volumen, listas de reproducción, etc.

Ten en cuenta que este código utiliza la API de Audio de HTML5 para reproducir el audio. Si no estás utilizando un navegador que no soporte esta API, el código no funcionará como esperas.

Es posible que el archivo JS no esté dentro de tu estructura de archivos por ahora, entonces lo puedes tener igualmente en un archivo separado. 

Espero te ayude.
*/
