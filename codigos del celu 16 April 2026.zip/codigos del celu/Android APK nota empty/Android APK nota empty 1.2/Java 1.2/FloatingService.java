//version 1.2

package leonardosotelo89.ls89.notaempty;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.LinearLayout;

public class FloatingService extends Service {
	
	private WindowManager windowManager;
	private View rootView;
	private WindowManager.LayoutParams params;
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		
		FrameLayout root = new FrameLayout(this);
		root.setBackgroundColor(0xCC000000);
		root.setPadding(16,16,16,16);
		
		// EDITTEXT
		EditText editText = new EditText(this);
		editText.setText("Pega texto aquí...");
		editText.setTextColor(0xFFFFFFFF);
		editText.setBackgroundColor(0x00000000);
		
		// BOTÓN CLOSE
		TextView closeBtn = new TextView(this);
		closeBtn.setText("✕");
		closeBtn.setTextColor(0xFFFFFFFF);
		closeBtn.setTextSize(18);
		
		FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(
		FrameLayout.LayoutParams.WRAP_CONTENT,
		FrameLayout.LayoutParams.WRAP_CONTENT
		);
		closeParams.gravity = Gravity.END | Gravity.TOP;
		closeBtn.setLayoutParams(closeParams);
		
		closeBtn.setOnClickListener(v -> stopSelf()); // kill servicio
		
		// HANDLE RESIZE
		View resizer = new View(this);
		resizer.setBackgroundColor(0xFFFFFFFF);
		
		FrameLayout.LayoutParams resizeParams = new FrameLayout.LayoutParams(40, 40);
		resizeParams.gravity = Gravity.END | Gravity.BOTTOM;
		resizer.setLayoutParams(resizeParams);
		
		root.addView(editText);
		root.addView(closeBtn);
		root.addView(resizer);
		
		rootView = root;
		
		params = new WindowManager.LayoutParams(
		500,
		500,
		WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
		WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
		PixelFormat.TRANSLUCENT
		);
		
		params.gravity = Gravity.TOP | Gravity.START;
		params.x = 100;
		params.y = 200;
		
		windowManager.addView(rootView, params);
		
		TextView settingsBtn = new TextView(this);
settingsBtn.setText("⚙");
settingsBtn.setTextColor(0xFFFFFFFF);

FrameLayout.LayoutParams settingsParams = new FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.WRAP_CONTENT,
        FrameLayout.LayoutParams.WRAP_CONTENT
);
settingsParams.gravity = Gravity.START | Gravity.TOP;
settingsBtn.setLayoutParams(settingsParams);

root.addView(settingsBtn);

LinearLayout panel = new LinearLayout(this);
panel.setOrientation(LinearLayout.VERTICAL);
panel.setBackgroundColor(0xEE222222);
panel.setPadding(10,10,10,10);
panel.setVisibility(View.GONE);

FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
        500,
        FrameLayout.LayoutParams.WRAP_CONTENT
);
panelParams.gravity = Gravity.TOP | Gravity.START;
panelParams.topMargin = 60; // debajo del botón ⚙
panel.setLayoutParams(panelParams);
	
	SeekBar rBg = new SeekBar(this); rBg.setMax(255);
SeekBar gBg = new SeekBar(this); gBg.setMax(255);
SeekBar bBg = new SeekBar(this); bBg.setMax(255);
SeekBar aBg = new SeekBar(this); aBg.setMax(255);
aBg.setProgress(200); // transparencia inicial

panel.addView(rBg);
panel.addView(gBg);
panel.addView(bBg);
panel.addView(aBg);

SeekBar rText = new SeekBar(this); rText.setMax(255);
SeekBar gText = new SeekBar(this); gText.setMax(255);
SeekBar bText = new SeekBar(this); bText.setMax(255);

panel.addView(rText);
panel.addView(gText);
panel.addView(bText);
	
	SeekBar textSize = new SeekBar(this);
textSize.setMax(100);
textSize.setProgress(16);

panel.addView(textSize);
	
	SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
    @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        int bgColor = android.graphics.Color.argb(
                aBg.getProgress(),
                rBg.getProgress(),
                gBg.getProgress(),
                bBg.getProgress()
        );

        int textColor = android.graphics.Color.rgb(
                rText.getProgress(),
                gText.getProgress(),
                bText.getProgress()
        );

        root.setBackgroundColor(bgColor);
        editText.setTextColor(textColor);
        editText.setTextSize(textSize.getProgress());
    }

    @Override public void onStartTrackingTouch(SeekBar seekBar) {}
    @Override public void onStopTrackingTouch(SeekBar seekBar) {}
};

// asignar listener a todos
rBg.setOnSeekBarChangeListener(listener);
gBg.setOnSeekBarChangeListener(listener);
bBg.setOnSeekBarChangeListener(listener);
aBg.setOnSeekBarChangeListener(listener);

rText.setOnSeekBarChangeListener(listener);
gText.setOnSeekBarChangeListener(listener);
bText.setOnSeekBarChangeListener(listener);

textSize.setOnSeekBarChangeListener(listener);
	
	settingsBtn.setOnClickListener(v -> {
    panel.setVisibility(panel.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
});

root.addView(panel);
		
		makeDraggable(root);
		makeResizable(resizer);
	}
	
	private void makeDraggable(View view) {
		view.setOnTouchListener(new View.OnTouchListener() {
			int initialX, initialY;
			float initialTouchX, initialTouchY;
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return false;
					
					case MotionEvent.ACTION_MOVE:
					params.x = initialX + (int)(event.getRawX() - initialTouchX);
					params.y = initialY + (int)(event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(rootView, params);
					return true;
				}
				return false;
			}
		});
	}
	
	private void makeResizable(View resizer) {
		resizer.setOnTouchListener(new View.OnTouchListener() {
			int initialWidth, initialHeight;
			float initialX, initialY;
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					initialWidth = params.width;
					initialHeight = params.height;
					initialX = event.getRawX();
					initialY = event.getRawY();
					return true;
					
					case MotionEvent.ACTION_MOVE:
					int dx = (int)(event.getRawX() - initialX);
					int dy = (int)(event.getRawY() - initialY);
					
					params.width = Math.max(300, initialWidth + dx);
					params.height = Math.max(200, initialHeight + dy);
					
					windowManager.updateViewLayout(rootView, params);
					return true;
				}
				return false;
			}
		});
	}
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (rootView != null) windowManager.removeView(rootView);
	}
}