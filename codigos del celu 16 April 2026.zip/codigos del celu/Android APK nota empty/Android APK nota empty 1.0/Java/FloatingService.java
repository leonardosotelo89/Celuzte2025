package leonardosotelo89.ls89.notaempty;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

public class FloatingService extends Service {
	
	private WindowManager windowManager;
	private View rootView;
	private WindowManager.LayoutParams params;
	
	@Override
	public void onCreate() {
		super.onCreate();
		
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
		
		FrameLayout root = new FrameLayout(this);
		root.setBackgroundColor(0xCC000000);
		root.setPadding(16,16,16,16);
		
		// EDITTEXT
		EditText editText = new EditText(this);
		editText.setText("Pega texto aquí...");
		editText.setTextColor(0xFFFFFFFF);
		editText.setBackgroundColor(0x00000000);
		
		// BOTÓN CLOSE
		TextView closeBtn = new TextView(this);
		closeBtn.setText("✕");
		closeBtn.setTextColor(0xFFFFFFFF);
		closeBtn.setTextSize(18);
		
		FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(
		FrameLayout.LayoutParams.WRAP_CONTENT,
		FrameLayout.LayoutParams.WRAP_CONTENT
		);
		closeParams.gravity = Gravity.END | Gravity.TOP;
		closeBtn.setLayoutParams(closeParams);
		
		closeBtn.setOnClickListener(v -> stopSelf()); // kill servicio
		
		// HANDLE RESIZE
		View resizer = new View(this);
		resizer.setBackgroundColor(0xFFFFFFFF);
		
		FrameLayout.LayoutParams resizeParams = new FrameLayout.LayoutParams(40, 40);
		resizeParams.gravity = Gravity.END | Gravity.BOTTOM;
		resizer.setLayoutParams(resizeParams);
		
		root.addView(editText);
		root.addView(closeBtn);
		root.addView(resizer);
		
		rootView = root;
		
		params = new WindowManager.LayoutParams(
		500,
		300,
		WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
		WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
		PixelFormat.TRANSLUCENT
		);
		
		params.gravity = Gravity.TOP | Gravity.START;
		params.x = 100;
		params.y = 200;
		
		windowManager.addView(rootView, params);
		
		makeDraggable(root);
		makeResizable(resizer);
	}
	
	private void makeDraggable(View view) {
		view.setOnTouchListener(new View.OnTouchListener() {
			int initialX, initialY;
			float initialTouchX, initialTouchY;
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return false;
					
					case MotionEvent.ACTION_MOVE:
					params.x = initialX + (int)(event.getRawX() - initialTouchX);
					params.y = initialY + (int)(event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(rootView, params);
					return true;
				}
				return false;
			}
		});
	}
	
	private void makeResizable(View resizer) {
		resizer.setOnTouchListener(new View.OnTouchListener() {
			int initialWidth, initialHeight;
			float initialX, initialY;
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
					initialWidth = params.width;
					initialHeight = params.height;
					initialX = event.getRawX();
					initialY = event.getRawY();
					return true;
					
					case MotionEvent.ACTION_MOVE:
					int dx = (int)(event.getRawX() - initialX);
					int dy = (int)(event.getRawY() - initialY);
					
					params.width = Math.max(300, initialWidth + dx);
					params.height = Math.max(200, initialHeight + dy);
					
					windowManager.updateViewLayout(rootView, params);
					return true;
				}
				return false;
			}
		});
	}
	
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (rootView != null) windowManager.removeView(rootView);
	}
}