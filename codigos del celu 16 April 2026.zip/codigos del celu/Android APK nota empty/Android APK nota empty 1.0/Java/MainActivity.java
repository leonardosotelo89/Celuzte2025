package leonardosotelo89.ls89.notaempty;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.View;
import android.view.ViewGroup;

public class MainActivity extends Activity {
	
	private static final int OVERLAY_PERMISSION_CODE = 1001;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		// UI mínima sin XML (un botón)
		LinearLayout layout = new LinearLayout(this);
		layout.setLayoutParams(new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT,
		ViewGroup.LayoutParams.MATCH_PARENT
		));
		layout.setGravity(android.view.Gravity.CENTER);
		
		Button button = new Button(this);
		button.setText("Abrir nota flotante");
		
		layout.addView(button);
		setContentView(layout);
		
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				if (!Settings.canDrawOverlays(MainActivity.this)) {
					// pedir permiso
					Intent intent = new Intent(
					Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
					Uri.parse("package:" + getPackageName())
					);
					startActivityForResult(intent, OVERLAY_PERMISSION_CODE);
					} else {
					// lanzar servicio
					startFloatingService();
				}
			}
		});
	}
	
	private void startFloatingService() {
		Intent intent = new Intent(MainActivity.this, FloatingService.class);
		startService(intent);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == OVERLAY_PERMISSION_CODE) {
			if (Settings.canDrawOverlays(this)) {
				startFloatingService();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}