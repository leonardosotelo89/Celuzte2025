package com.example.sendtotv;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.Context;
import android.webkit.WebViewClient;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.util.ArrayList;

public class MainActivity extends Activity {

    WebView web;

    ArrayList<Uri> files = new ArrayList<>();

    LocalServer server;

    static final int PICK_FILES = 100;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        web = new WebView(this);

        WebSettings settings = web.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());

        web.addJavascriptInterface(
            new Android(this),
            "Android"
        );

        setContentView(web);

        web.loadDataWithBaseURL(
            null,
            HTML,
            "text/html",
            "UTF-8",
            null
        );
    }

    void pickFiles() {

        Intent i =
            new Intent(Intent.ACTION_OPEN_DOCUMENT);

        i.setType("*/*");

        i.putExtra(
            Intent.EXTRA_ALLOW_MULTIPLE,
            true
        );

        i.addCategory(
            Intent.CATEGORY_OPENABLE
        );

        startActivityForResult(
            i,
            PICK_FILES
        );
    }

    @Override
    protected void onActivityResult(
        int request,
        int result,
        Intent data
    ) {

        super.onActivityResult(
            request,
            result,
            data
        );

        if (
            request != PICK_FILES ||
            result != RESULT_OK ||
            data == null
        ) {
            return;
        }

        files.clear();

        if (data.getClipData() != null) {

            int n =
                data.getClipData()
                   .getItemCount();

            for (int x = 0; x < n; x++) {

                Uri uri =
                    data.getClipData()
                       .getItemAt(x)
                       .getUri();

                files.add(uri);
            }

        } else if (data.getData() != null) {

            files.add(data.getData());
        }

        if (server == null) {

            server =
                new LocalServer(
                    this,
                    8080
                );

            server.start();
        }

        sendFileListToWeb();
    }

    void sendFileListToWeb() {

        StringBuilder js =
            new StringBuilder();

        js.append("clearFiles();");

        for (
            int x = 0;
            x < files.size();
            x++
        ) {

            String name =
                getFileName(
                    files.get(x)
                );

            String url =
                "http://" +
                getLocalIp() +
                ":8080/file/" +
                x;

            js.append(
                "addFile(" +
                jsString(name) +
                "," +
                jsString(url) +
                ");"
            );
        }

        web.post(() ->
            web.evaluateJavascript(
                js.toString(),
                null
            )
        );
    }

    String getFileName(Uri uri) {

        Cursor c =
            getContentResolver().query(
                uri,
                null,
                null,
                null,
                null
            );

        if (c != null) {

            try {

                int index =
                    c.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                    );

                if (
                    c.moveToFirst() &&
                    index >= 0
                ) {

                    return c.getString(index);
                }

            } finally {

                c.close();
            }
        }

        return "archivo";
    }

    String getLocalIp() {

        try {

            for (
                java.util.Enumeration<
                    java.net.NetworkInterface
                > e =
                    java.net.NetworkInterface
                    .getNetworkInterfaces();

                e.hasMoreElements();

            ) {

                java.net.NetworkInterface ni =
                    e.nextElement();

                for (
                    java.util.Enumeration<
                        java.net.InetAddress
                    > a =
                        ni.getInetAddresses();

                    a.hasMoreElements();

                ) {

                    InetAddress ip =
                        a.nextElement();

                    if (
                        !ip.isLoopbackAddress() &&
                        ip.getHostAddress()
                          .indexOf(":") == -1
                    ) {

                        return ip.getHostAddress();
                    }
                }
            }

        } catch (Exception e) {
        }

        return "127.0.0.1";
    }

    String jsString(String s) {

        return "'" +
            s.replace("\\", "\\\\")
             .replace("'", "\\'")
             .replace("\n", "\\n")
             .replace("\r", "") +
            "'";
    }

    class Android {

        Context context;

        Android(Context c) {
            context = c;
        }

        @JavascriptInterface
        public void selectFiles() {

            runOnUiThread(() ->
                pickFiles()
            );
        }

        @JavascriptInterface
        public String getIP() {

            return getLocalIp();
        }
    }

    static class LocalServer extends Thread {

        MainActivity activity;

        int port;

        ServerSocket serverSocket;

        LocalServer(
            MainActivity a,
            int p
        ) {

            activity = a;
            port = p;
        }

        @Override
        public void run() {

            try {

                serverSocket =
                    new ServerSocket(
                        port,
                        50,
                        InetAddress.getByName(
                            "0.0.0.0"
                        )
                    );

                while (!isInterrupted()) {

                    Socket socket =
                        serverSocket.accept();

                    new Thread(() ->
                        handle(socket)
                    ).start();
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

        void handle(Socket socket) {

            try {

                InputStream in =
                    socket.getInputStream();

                String request =
                    readRequest(in);

                if (!request.startsWith("GET ")) {

                    socket.close();
                    return;
                }

                String[] parts =
                    request.split(" ");

                if (parts.length < 2) {

                    socket.close();
                    return;
                }

                String path =
                    parts[1];

                /*
                 * PAGINA PRINCIPAL
                 */

                if (path.equals("/")) {

                    sendIndex(socket);

                    socket.close();

                    return;
                }

                /*
                 * ARCHIVO
                 */

                if (
                    path.startsWith("/file/")
                ) {

                    String number =
                        path.substring(6);

                    int index;

                    try {

                        index =
                            Integer.parseInt(
                                number
                            );

                    } catch (Exception e) {

                        send404(
                            socket.getOutputStream()
                        );

                        socket.close();

                        return;
                    }

                    if (
                        index < 0 ||
                        index >=
                        activity.files.size()
                    ) {

                        send404(
                            socket.getOutputStream()
                        );

                        socket.close();

                        return;
                    }

                    Uri uri =
                        activity.files.get(index);

                    streamFile(
                        socket,
                        uri,
                        request
                    );

                    return;
                }

                send404(
                    socket.getOutputStream()
                );

                socket.close();

            } catch (Exception e) {

                e.printStackTrace();

                try {
                    socket.close();
                } catch (Exception ignored) {
                }
            }
        }

        String readRequest(
            InputStream in
        ) throws Exception {

            StringBuilder s =
                new StringBuilder();

            int last = 0;

            while (true) {

                int c = in.read();

                if (c == -1)
                    break;

                s.append((char)c);

                if (
                    last == '\r' &&
                    c == '\n'
                ) {

                    String t =
                        s.toString();

                    if (
                        t.endsWith(
                            "\r\n\r\n"
                        )
                    ) {

                        break;
                    }
                }

                last = c;
            }

            return s.toString();
        }

        void sendIndex(
            Socket socket
        ) throws Exception {

            StringBuilder html =
                new StringBuilder();

            html.append(
                "<!DOCTYPE html>"
            );

            html.append(
                "<html><head>"
            );

            html.append(
                "<meta name='viewport' " +
                "content='width=device-width," +
                "initial-scale=1'>"
            );

            html.append(
                "<title>Send To TV</title>"
            );

            html.append("<style>");

            html.append(
                "body{" +
                "background:#000;" +
                "color:#0f0;" +
                "font-family:sans-serif;" +
                "padding:25px;" +
                "}"
            );

            html.append(
                "h1{" +
                "text-align:center;" +
                "}"
            );

            html.append(
                ".file{" +
                "display:block;" +
                "padding:20px;" +
                "margin:12px 0;" +
                "background:#111;" +
                "color:#0f0;" +
                "border:2px solid #0f0;" +
                "border-radius:8px;" +
                "text-decoration:none;" +
                "font-size:20px;" +
                "}"
            );

            html.append("</style>");

            html.append(
                "</head><body>"
            );

            html.append(
                "<h1>SEND TO TV</h1>"
            );

            html.append(
                "<p>Selecciona un archivo:</p>"
            );

            for (
                int x = 0;
                x < activity.files.size();
                x++
            ) {

                String name =
                    activity.getFileName(
                        activity.files.get(x)
                    );

                html.append(
                    "<a class='file' " +
                    "href='/file/" +
                    x +
                    "' download>"
                );

                html.append(
                    escapeHtml(name)
                );

                html.append(
                    "</a>"
                );
            }

            if (
                activity.files.size() == 0
            ) {

                html.append(
                    "<p>No hay archivos.</p>"
                );
            }

            html.append(
                "</body></html>"
            );

            sendHtml(
                socket.getOutputStream(),
                html.toString()
            );
        }

        String escapeHtml(String s) {

            return s
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
        }

        void sendHtml(
            OutputStream out,
            String html
        ) throws Exception {

            byte[] b =
                html.getBytes("UTF-8");

            String h =
                "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; " +
                "charset=UTF-8\r\n" +
                "Content-Length: " +
                b.length +
                "\r\n" +
                "Connection: close\r\n\r\n";

            out.write(
                h.getBytes("UTF-8")
            );

            out.write(b);

            out.flush();
        }

        void streamFile(
            Socket socket,
            Uri uri,
            String request
        ) throws Exception {

            long size =
                getSize(uri);

            if (size <= 0) {

                send404(
                    socket.getOutputStream()
                );

                socket.close();

                return;
            }

            long start = 0;

            long end =
                size - 1;

            String range =
                getHeader(
                    request,
                    "Range:"
                );

            boolean partial =
                range != null;

            if (partial) {

                range =
                    range
                    .replace(
                        "Range:",
                        ""
                    )
                    .trim();

                range =
                    range.replace(
                        "bytes=",
                        ""
                    );

                String[] p =
                    range.split("-");

                start =
                    Long.parseLong(
                        p[0]
                    );

                if (
                    p.length > 1 &&
                    p[1].length() > 0
                ) {

                    end =
                        Long.parseLong(
                            p[1]
                        );
                }
            }

            if (start >= size) {

                send416(
                    socket.getOutputStream(),
                    size
                );

                socket.close();

                return;
            }

            if (end >= size) {

                end =
                    size - 1;
            }

            long length =
                end - start + 1;

            String mime =
                activity
                .getContentResolver()
                .getType(uri);

            if (mime == null) {

                mime =
                    "application/octet-stream";
            }

            OutputStream out =
                socket.getOutputStream();

            String header =
                (partial
                    ? "HTTP/1.1 206 Partial Content\r\n"
                    : "HTTP/1.1 200 OK\r\n")

                + "Content-Type: "
                + mime
                + "\r\n"

                + "Content-Length: "
                + length
                + "\r\n"

                + "Accept-Ranges: bytes\r\n";

            if (partial) {

                header +=
                    "Content-Range: bytes " +
                    start +
                    "-" +
                    end +
                    "/" +
                    size +
                    "\r\n";
            }

            /*
             * APK:
             * obliga al navegador a descargarlo.
             */

            if (
                mime.equals(
                    "application/vnd.android.package-archive"
                )
            ) {

                header +=
                    "Content-Disposition: attachment; " +
                    "filename=\"" +
                    activity.getFileName(uri) +
                    "\"\r\n";
            }

            header +=
                "Connection: close\r\n\r\n";

            out.write(
                header.getBytes("UTF-8")
            );

            InputStream in =
                activity
                .getContentResolver()
                .openInputStream(uri);

            if (in == null)
                throw new IOException();

            skipFully(
                in,
                start
            );

            byte[] buffer =
                new byte[64 * 1024];

            long remaining =
                length;

            while (remaining > 0) {

                int wanted =
                    (int)Math.min(
                        buffer.length,
                        remaining
                    );

                int read =
                    in.read(
                        buffer,
                        0,
                        wanted
                    );

                if (read == -1)
                    break;

                out.write(
                    buffer,
                    0,
                    read
                );

                remaining -= read;
            }

            in.close();

            out.flush();

            socket.close();
        }

        void skipFully(
            InputStream in,
            long n
        ) throws Exception {

            while (n > 0) {

                long x =
                    in.skip(n);

                if (x <= 0) {

                    if (in.read() == -1)
                        break;

                    x = 1;
                }

                n -= x;
            }
        }

        long getSize(Uri uri) {

            Cursor c =
                activity
                .getContentResolver()
                .query(
                    uri,
                    new String[]{
                        OpenableColumns.SIZE
                    },
                    null,
                    null,
                    null
                );

            if (c != null) {

                try {

                    if (c.moveToFirst()) {

                        int i =
                            c.getColumnIndex(
                                OpenableColumns.SIZE
                            );

                        if (i >= 0)
                            return c.getLong(i);
                    }

                } finally {

                    c.close();
                }
            }

            return 0;
        }

        String getHeader(
            String request,
            String name
        ) {

            String[] lines =
                request.split("\r\n");

            for (String line : lines) {

                if (
                    line.startsWith(name)
                ) {

                    return line;
                }
            }

            return null;
        }

        void send404(
            OutputStream out
        ) throws Exception {

            String h =
                "HTTP/1.1 404 Not Found\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n";

            out.write(
                h.getBytes("UTF-8")
            );
        }

        void send416(
            OutputStream out,
            long size
        ) throws Exception {

            String h =
                "HTTP/1.1 416 Range Not Satisfiable\r\n" +
                "Content-Range: bytes */" +
                size +
                "\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n";

            out.write(
                h.getBytes("UTF-8")
            );
        }
    }

    static final String HTML =

        "<!DOCTYPE html>" +

        "<html>" +

        "<head>" +

        "<meta name='viewport' " +
        "content='width=device-width," +
        "initial-scale=1'>" +

        "<style>" +

        "*{" +
        "box-sizing:border-box;" +
        "margin:0;" +
        "padding:0;" +
        "}" +

        "body{" +
        "background:#000;" +
        "color:#0f0;" +
        "font-family:sans-serif;" +
        "padding:25px;" +
        "}" +

        "h1{" +
        "text-align:center;" +
        "font-size:28px;" +
        "margin-bottom:30px;" +
        "}" +

        "button{" +
        "display:block;" +
        "width:100%;" +
        "padding:20px;" +
        "margin-bottom:15px;" +
        "font-size:20px;" +
        "background:#003300;" +
        "color:#0f0;" +
        "border:2px solid #0f0;" +
        "border-radius:8px;" +
        "}" +

        "#info{" +
        "text-align:center;" +
        "margin:20px 0;" +
        "}" +

        ".file{" +
        "display:block;" +
        "padding:15px;" +
        "margin:8px 0;" +
        "background:#111;" +
        "color:#fff;" +
        "text-decoration:none;" +
        "border:1px solid #333;" +
        "border-radius:5px;" +
        "}" +

        "</style>" +

        "</head>" +

        "<body>" +

        "<h1>SEND TO TV</h1>" +

        "<button onclick='Android.selectFiles()'>" +
        "SELECCIONAR ARCHIVOS" +
        "</button>" +

        "<div id='info'>" +
        "Selecciona archivos" +
        "</div>" +

        "<div id='files'></div>" +

        "<script>" +

        "function clearFiles(){" +
        "document.getElementById('files')" +
        ".innerHTML='';" +
        "}" +

        "function addFile(name,url){" +

        "let a=" +
        "document.createElement('a');" +

        "a.className='file';" +

        "a.href=url;" +

        "a.target='_blank';" +

        "a.innerText=name;" +

        "document.getElementById('files')" +
        ".appendChild(a);" +

        "document.getElementById('info')" +
        ".innerText=" +
        "'Servidor: '+" +
        "Android.getIP()+':8080';" +

        "}" +

        "</script>" +

        "</body>" +

        "</html>";
}