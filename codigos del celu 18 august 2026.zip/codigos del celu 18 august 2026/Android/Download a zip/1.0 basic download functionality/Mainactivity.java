package sotelo.leonardo.screenorientationportrait;

//replace all after package reference 
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();

        webSettings.setJavaScriptEnabled(true);

        webView.setWebViewClient(new WebViewClient());

        // DOWNLOAD SUPPORT
        webView.setDownloadListener(new DownloadListener() {

            @Override
            public void onDownloadStart(
                    String url,
                    String userAgent,
                    String contentDisposition,
                    String mimetype,
                    long contentLength) {

                DownloadManager.Request request =
                        new DownloadManager.Request(Uri.parse(url));

                request.allowScanningByMediaScanner();

                request.setNotificationVisibility(
                        DownloadManager.Request
                                .VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        "downloaded_file");

                DownloadManager dm =
                        (DownloadManager) getSystemService(
                                Context.DOWNLOAD_SERVICE);

                dm.enqueue(request);
            }
        });

        webView.loadUrl(
                "https://leonardosotelo89.gitlab.io/codes_from_tablet_huawei");
    }
}