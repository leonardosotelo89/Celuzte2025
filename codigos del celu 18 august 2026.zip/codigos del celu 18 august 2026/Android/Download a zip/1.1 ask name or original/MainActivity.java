import android.app.AlertDialog;
import android.widget.EditText;

webView.setDownloadListener(new DownloadListener() {

    @Override
    public void onDownloadStart(
            String url,
            String userAgent,
            String contentDisposition,
            String mimetype,
            long contentLength) {

        EditText editText = new EditText(MainActivity.this);

        editText.setHint("archivo.zip");

        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Save file as")
                .setView(editText)

                .setPositiveButton("Download",
                        (dialog, which) -> {

                    String fileName =
                            editText.getText().toString();

                    if(fileName.isEmpty()) {
                        fileName = "download.zip";
                    }

                    DownloadManager.Request request =
                            new DownloadManager.Request(
                                    Uri.parse(url));

                    request.setNotificationVisibility(
                            DownloadManager.Request
                            .VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                    request.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            fileName);

                    DownloadManager dm =
                            (DownloadManager)
                            getSystemService(
                            Context.DOWNLOAD_SERVICE);

                    dm.enqueue(request);
                })

                .setNegativeButton("Cancel", null)
                .show();
    }
});


/*
String fileName =
        url.substring(url.lastIndexOf("/") + 1);

request.setDestinationInExternalPublicDir(
        Environment.DIRECTORY_DOWNLOADS,
        fileName);
*/