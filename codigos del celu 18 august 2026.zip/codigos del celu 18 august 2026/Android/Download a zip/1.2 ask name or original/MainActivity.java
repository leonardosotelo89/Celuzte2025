package sotelo.leonardo.screenorientationportrait;

//paste this code after package reference
//replace all after package reference
		import android.app.Activity;
		import android.app.DownloadManager;
		import android.content.Context;
		import android.net.Uri;
		import android.os.Bundle;
		import android.os.Environment;
		import android.webkit.DownloadListener;
		import android.webkit.WebSettings;
		import android.webkit.WebView;
		import android.webkit.WebViewClient;
		import android.view.Window;
		
		import android.app.AlertDialog;
        import android.widget.EditText;
		
		public class MainActivity extends Activity {
			
			@Override
			protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				
				requestWindowFeature(Window.FEATURE_NO_TITLE);
				
				WebView webView = new WebView(this);
				setContentView(webView);
				
				WebSettings webSettings = webView.getSettings();
				
				webSettings.setJavaScriptEnabled(true);
				
				webView.setWebViewClient(new WebViewClient());
				
				// DOWNLOAD SUPPORT					
		webView.setDownloadListener(new DownloadListener() {

        @Override
        public void onDownloadStart(
            String url,
            String userAgent,
            String contentDisposition,
            String mimetype,
            long contentLength) {

        EditText editText = new EditText(MainActivity.this);

        editText.setHint("archivo.zip");

        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Save file as")
                .setView(editText)

                .setPositiveButton("Download",
                        (dialog, which) -> {

                    String fileName =
                            editText.getText().toString();

                    if(fileName.isEmpty()) {
                        fileName = "download.zip";
                    }

                    DownloadManager.Request request =
                            new DownloadManager.Request(
                                    Uri.parse(url));

                    request.setNotificationVisibility(
                            DownloadManager.Request
                            .VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                    request.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            fileName);

                    DownloadManager dm =
                            (DownloadManager)
                            getSystemService(
                            Context.DOWNLOAD_SERVICE);

                    dm.enqueue(request);
                })

                .setNegativeButton("Cancel", null)
                .show();
                }
        });


/*
String fileName =
        url.substring(url.lastIndexOf("/") + 1);

request.setDestinationInExternalPublicDir(
        Environment.DIRECTORY_DOWNLOADS,
        fileName);
*/
				
				// Load an online URL
				webView.loadUrl("https://leonardosotelo89.gitlab.io/codes_from_tablet_huawei");  // Replace with the URL you want to load
			}
		}		


