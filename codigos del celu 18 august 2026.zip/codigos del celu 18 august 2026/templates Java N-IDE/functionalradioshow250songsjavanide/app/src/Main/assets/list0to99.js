const list1 = []  
  
 list1[0] = { 
   intro:['rosesareredintro1.mp3', 
          'rosesareredintro2.mp3',  
          'rosesareredintro3.mp3', 
          'rosesareredintro4.mp3',  
          'rosesareredintro5.mp3', 
          'rosesareredintro6.mp3',  
          'rosesareredintro7.mp3', 
          'rosesareredintro8.mp3',  
          'rosesareredintro9.mp3', 
          'rosesareredintro10.mp3',  
          'rosesareredintro11.mp3'], 
   song:'aquarosesarered.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: dinamarca (🇩🇰) / interprete: aqua / cancion: roses are red &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[1] = { 
   intro:['yalanintro1.mp3', 
          'yalanintro2.mp3',  
          'yalanintro3.mp3', 
          'yalanintro4.mp3',  
          'yalanintro5.mp3', 
          'yalanintro6.mp3',  
          'yalanintro7.mp3', 
          'yalanintro8.mp3',  
          'yalanintro9.mp3', 
          'yalanintro10.mp3',  
          'yalanintro11.mp3', 
          'yalanintro12.mp3'], 
   song:'edisyalan.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Turquía (🇹🇷) / interprete: Edis / cancion: Yalan &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[2] = { 
   intro:['sotokorintro1.mp3', 
          'sotokorintro2.mp3',  
          'sotokorintro3.mp3', 
          'sotokorintro4.mp3',  
          'sotokorintro5.mp3', 
          'sotokorintro6.mp3',  
          'sotokorintro7.mp3', 
          'sotokorintro8.mp3',  
          'sotokorintro9.mp3', 
          'sotokorintro10.mp3',  
          'sotokorintro11.mp3', 
          'sotokorintro12.mp3'], 
   song:'fardinsaadatsotokor.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: Fardin Saadat / cancion: Soto Kor &nbsp&nbsp&nbsp&#160&#160&#160"  
 } 

 list1[3] = { 
   intro:['tymenyazabudintro1.mp3', 
          'tymenyazabudintro2.mp3',  
          'tymenyazabudintro3.mp3', 
          'tymenyazabudintro4.mp3',  
          'tymenyazabudintro5.mp3', 
          'tymenyazabudintro6.mp3',  
          'tymenyazabudintro7.mp3', 
          'tymenyazabudintro8.mp3',  
          'tymenyazabudintro9.mp3', 
          'tymenyazabudintro10.mp3',  
          'tymenyazabudintro11.mp3', 
          'tymenyazabudintro12.mp3'],  
   song:'djpiligrimtymenyazabud.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Uzbekistan (🇺🇿) / interprete: dj piligrim / cancion: ty menya zabud &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[4] = { 
   intro:['oynasunintro1.mp3', 
          'oynasunintro2.mp3',  
          'oynasunintro3.mp3', 
          'oynasunintro4.mp3',  
          'oynasunintro5.mp3', 
          'oynasunintro6.mp3',  
          'oynasunintro7.mp3', 
          'oynasunintro8.mp3',  
          'oynasunintro9.mp3', 
          'oynasunintro10.mp3',  
          'oynasunintro11.mp3', 
          'oynasunintro12.mp3',  
          'oynasunintro13.mp3'],  
   song:'shahrizodaoynasun.mp3', 
   text:"&nbsp&nbsp&nbsp&#160&#160&#160 pais: Uzbekistan (🇺🇿) / interprete: Shahrizoda / cancion: oynasun &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[5] = { 
   intro:['boroborointro1.mp3', 
          'boroborointro2.mp3',  
          'boroborointro3.mp3', 
          'boroborointro4.mp3',  
          'boroborointro5.mp3', 
          'boroborointro6.mp3',  
          'boroborointro7.mp3', 
          'boroborointro8.mp3',  
          'boroborointro9.mp3', 
          'boroborointro10.mp3',  
          'boroborointro11.mp3', 
          'boroborointro12.mp3'],  
   song:'arashboroboro.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: arash / cancion: boro boro &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[6] = { 
   intro:['krasotadushiintro1.mp3', 
          'krasotadushiintro2.mp3',  
          'krasotadushiintro3.mp3', 
          'krasotadushiintro4.mp3',  
          'krasotadushiintro5.mp3', 
          'krasotadushiintro6.mp3',  
          'krasotadushiintro7.mp3', 
          'krasotadushiintro8.mp3',  
          'krasotadushiintro9.mp3', 
          'krasotadushiintro10.mp3',  
          'krasotadushiintro11.mp3', 
          'krasotadushiintro12.mp3',  
          'krasotadushiintro13.mp3'],  
   song:'fatimaypieraijokrasotadushi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima y pier aijo / cancion: krasota dushi &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[7] = { 
   intro:['ageberiintro1.mp3', 
          'ageberiintro2.mp3',  
          'ageberiintro3.mp3', 
          'ageberiintro4.mp3',  
          'ageberiintro5.mp3', 
          'ageberiintro6.mp3',  
          'ageberiintro7.mp3', 
          'ageberiintro8.mp3',  
          'ageberiintro9.mp3', 
          'ageberiintro10.mp3',  
          'ageberiintro11.mp3'],  
   song:'maziarsammeageberi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: maziar samme / cancion: age beri &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[8] = { 
   intro:['manobavarkonintro1.mp3', 
          'manobavarkonintro2.mp3',  
          'manobavarkonintro3.mp3', 
          'manobavarkonintro4.mp3',  
          'manobavarkonintro5.mp3', 
          'manobavarkonintro6.mp3',  
          'manobavarkonintro7.mp3', 
          'manobavarkonintro8.mp3',  
          'manobavarkonintro9.mp3', 
          'manobavarkonintro10.mp3',  
          'manobavarkonintro11.mp3', 
          'manobavarkonintro12.mp3'],  
   song:'pouyabayatimanobavarkon.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: pouya bayati / cancion: mano bavar kon &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[9] = { 
   intro:['bimarefatintro1.mp3', 
          'bimarefatintro2.mp3',  
          'bimarefatintro3.mp3', 
          'bimarefatintro4.mp3',  
          'bimarefatintro5.mp3', 
          'bimarefatintro6.mp3',  
          'bimarefatintro7.mp3', 
          'bimarefatintro8.mp3',  
          'bimarefatintro9.mp3', 
          'bimarefatintro10.mp3',  
          'bimarefatintro11.mp3', 
          'bimarefatintro12.mp3',  
          'bimarefatintro13.mp3'],  
   song:'aliabdolmalekibimarefat.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: iran (🇮🇷) / interprete: ali abdolmaleki / cancion: bi marefat &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[10] = { 
   intro:['macalinaintro1.mp3', 
          'macalinaintro2.mp3',  
          'macalinaintro3.mp3', 
          'macalinaintro4.mp3',  
          'macalinaintro5.mp3', 
          'macalinaintro6.mp3',  
          'macalinaintro7.mp3', 
          'macalinaintro8.mp3',  
          'macalinaintro9.mp3', 
          'macalinaintro10.mp3',  
          'macalinaintro11.mp3'],  
   song:'kendjigiracmacalina.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: kendji girac / cancion: ma calina &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[11] = { 
   intro:['andalouseintro1.mp3', 
          'andalouseintro2.mp3',  
          'andalouseintro3.mp3', 
          'andalouseintro4.mp3',  
          'andalouseintro5.mp3', 
          'andalouseintro6.mp3',  
          'andalouseintro7.mp3', 
          'andalouseintro8.mp3',  
          'andalouseintro9.mp3', 
          'andalouseintro10.mp3',  
          'andalouseintro11.mp3', 
          'andalouseintro12.mp3',  
          'andalouseintro13.mp3'],  
   song:'kendjigiracandalouse.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: kendji girac / cancion: andalouse &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[12] = { 
   intro:['vibrasdelcaribeintro1.mp3', 
          'vibrasdelcaribeintro2.mp3',   
          'vibrasdelcaribeintro3.mp3',   
          'vibrasdelcaribeintro4.mp3',    
          'vibrasdelcaribeintro5.mp3',    
          'vibrasdelcaribeintro6.mp3',    
          'vibrasdelcaribeintro7.mp3',    
          'vibrasdelcaribeintro8.mp3',    
          'vibrasdelcaribeintro9.mp3',   
          'vibrasdelcaribeintro10.mp3',    
          'vibrasdelcaribeintro11.mp3',    
          'vibrasdelcaribeintro12.mp3',    
          'vibrasdelcaribeintro13.mp3',    
          'vibrasdelcaribeintro14.mp3',    
          'vibrasdelcaribeintro15.mp3' ],    
   song:'emozikvibrasdelcaribe.mp3',   
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bangladesh (🇧🇩) / interprete: Emozik / cancion: Vibras del Caribe  &nbsp&nbsp&nbsp&#160&#160&#160"   
 }  

 list1[13] = { 
   intro:['allaboutusintro1.mp3', 
          'allaboutusintro2.mp3',  
          'allaboutusintro3.mp3', 
          'allaboutusintro4.mp3',  
          'allaboutusintro5.mp3', 
          'allaboutusintro6.mp3',  
          'allaboutusintro7.mp3', 
          'allaboutusintro8.mp3',  
          'allaboutusintro9.mp3', 
          'allaboutusintro10.mp3',  
          'allaboutusintro11.mp3' ],  
   song:'tatuallaboutus.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: tatu / cancion: all about us &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[14] = { 
   intro:['allthethingsshesaidintro1.mp3', 
          'allthethingsshesaidintro2.mp3',  
          'allthethingsshesaidintro3.mp3', 
          'allthethingsshesaidintro4.mp3',  
          'allthethingsshesaidintro5.mp3', 
          'allthethingsshesaidintro6.mp3',  
          'allthethingsshesaidintro7.mp3', 
          'allthethingsshesaidintro8.mp3',  
          'allthethingsshesaidintro9.mp3', 
          'allthethingsshesaidintro10.mp3',  
          'allthethingsshesaidintro11.mp3'],  
   song:'tatuallthethingsshesaid.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: tatu / cancion: all the things she said &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[15] = { 
   intro:['pahaltapiilossaintro1.mp3', 
          'pahaltapiilossaintro2.mp3',  
          'pahaltapiilossaintro3.mp3', 
          'pahaltapiilossaintro4.mp3',  
          'pahaltapiilossaintro5.mp3', 
          'pahaltapiilossaintro6.mp3',  
          'pahaltapiilossaintro7.mp3', 
          'pahaltapiilossaintro8.mp3',  
          'pahaltapiilossaintro9.mp3', 
          'pahaltapiilossaintro10.mp3',  
          'pahaltapiilossaintro11.mp3', 
          'pahaltapiilossaintro12.mp3'],  
   song:'suviterasniskapahaltapiilossa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: finlandia (🇫🇮) / interprete: suvi terasniska / cancion: pahalta piilossa &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[16] = { 
   intro:['tirnanogintro1.mp3', 
          'tirnanogintro2.mp3',  
          'tirnanogintro3.mp3', 
          'tirnanogintro4.mp3',  
          'tirnanogintro5.mp3', 
          'tirnanogintro6.mp3',  
          'tirnanogintro7.mp3', 
          'tirnanogintro8.mp3',  
          'tirnanogintro9.mp3', 
          'tirnanogintro10.mp3',  
          'tirnanogintro11.mp3', 
          'tirnanogintro12.mp3'],  
   song:'celticwomantirnanog.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: irlanda (🇮🇪) / interprete: celtic woman / cancion: tir na nog &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[17] = { 
   intro:['naachmeriraniintro1.mp3', 
          'naachmeriraniintro2.mp3',  
          'naachmeriraniintro3.mp3', 
          'naachmeriraniintro4.mp3',  
          'naachmeriraniintro5.mp3', 
          'naachmeriraniintro6.mp3',  
          'naachmeriraniintro7.mp3', 
          'naachmeriraniintro8.mp3',  
          'naachmeriraniintro9.mp3', 
          'naachmeriraniintro10.mp3',  
          'naachmeriraniintro11.mp3', 
          'naachmeriraniintro12.mp3'],  
   song:'gururandhawaynorafatehinaachmerirani.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) - canada (🇨🇦) / interprete: guru randhawa y nora fatehi / cancion: naach meri rani &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[18] = { 
   intro:['tandangintro1.mp3', 
          'tandangintro2.mp3',  
          'tandangintro3.mp3', 
          'tandangintro4.mp3',  
          'tandangintro5.mp3', 
          'tandangintro6.mp3',  
          'tandangintro7.mp3', 
          'tandangintro8.mp3',  
          'tandangintro9.mp3', 
          'tandangintro10.mp3',  
          'tandangintro11.mp3', 
          'tandangintro12.mp3',  
          'tandangintro13.mp3'],  
   song:'djk8remixcaojintandang.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: djk8 remix cao jin / cancion: tandang &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[19] = { 
   intro:['boshretkheirintro1.mp3', 
          'boshretkheirintro2.mp3',  
          'boshretkheirintro3.mp3', 
          'boshretkheirintro4.mp3',  
          'boshretkheirintro5.mp3', 
          'boshretkheirintro6.mp3',  
          'boshretkheirintro7.mp3', 
          'boshretkheirintro8.mp3',  
          'boshretkheirintro9.mp3', 
          'boshretkheirintro10.mp3',  
          'boshretkheirintro11.mp3', 
          'boshretkheirintro12.mp3'],  
   song:'djmusaliboshretkheir.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: emiratos arabes unidos (🇦🇪) / interprete: dj musali (black arabia) / cancion: boshret kheir &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[20] = { 
   intro:['venavenaintro1.mp3', 
          'venavenaintro2.mp3',  
          'venavenaintro3.mp3', 
          'venavenaintro4.mp3',  
          'venavenaintro5.mp3', 
          'venavenaintro6.mp3',  
          'venavenaintro7.mp3', 
          'venavenaintro8.mp3',  
          'venavenaintro9.mp3', 
          'venavenaintro10.mp3',  
          'venavenaintro11.mp3'],  
   song:'sozersepetcivenavena.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: sözer sepetçi / cancion: vêna vêna &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[21] = { 
   intro:['amenointro1.mp3', 
          'amenointro2.mp3',  
          'amenointro3.mp3', 
          'amenointro4.mp3',  
          'amenointro5.mp3', 
          'amenointro6.mp3',  
          'amenointro7.mp3', 
          'amenointro8.mp3',  
          'amenointro9.mp3', 
          'amenointro10.mp3',  
          'amenointro11.mp3'],  
   song:'eraameno.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: francia (🇫🇷) / interprete: era / cancion: ameno &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[22] = { 
   intro:['xanaduintro1.mp3', 
          'xanaduintro2.mp3',  
          'xanaduintro3.mp3', 
          'xanaduintro4.mp3',  
          'xanaduintro5.mp3', 
          'xanaduintro6.mp3',  
          'xanaduintro7.mp3', 
          'xanaduintro8.mp3',  
          'xanaduintro9.mp3', 
          'xanaduintro10.mp3',  
          'xanaduintro11.mp3', 
          'xanaduintro12.mp3',  
          'xanaduintro13.mp3'],  
   song:'ummetozcanxanadu.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: holanda (🇳🇱) / interprete: ummet ozcan / cancion: xanadu &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[23] = { 
   intro:['ayimointro1.mp3', 
          'ayimointro2.mp3', 
          'ayimointro3.mp3',  
          'ayimointro4.mp3', 
          'ayimointro5.mp3', 
          'ayimointro6.mp3', 
          'ayimointro7.mp3', 
          'ayimointro8.mp3', 
          'ayimointro9.mp3',  
          'ayimointro10.mp3', 
          'ayimointro11.mp3', 
          'ayimointro12.mp3'],  
   song:'grupoajitaiayimo.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: grupo ajitai / cancion: ayimo &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[24] = { 
   intro:['daritezhenshchinamtsvetyintro1.mp3', 
          'daritezhenshchinamtsvetyintro2.mp3',  
          'daritezhenshchinamtsvetyintro3.mp3', 
          'daritezhenshchinamtsvetyintro4.mp3', 
          'daritezhenshchinamtsvetyintro5.mp3', 
          'daritezhenshchinamtsvetyintro6.mp3',  
          'daritezhenshchinamtsvetyintro7.mp3', 
          'daritezhenshchinamtsvetyintro8.mp3',  
          'daritezhenshchinamtsvetyintro9.mp3', 
          'daritezhenshchinamtsvetyintro10.mp3',  
          'daritezhenshchinamtsvetyintro11.mp3'],  
   song:'jazzdaurendaritezhenshchinamtsvety.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Kazajistán (🇰🇿) / interprete: jazzdauren / cancion: darite zhenshchinam tsvety &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[25] = { 
   intro:['gulyanananeyintro1.mp3', 
          'gulyanananeyintro2.mp3',  
          'gulyanananeyintro3.mp3', 
          'gulyanananeyintro4.mp3',  
          'gulyanananeyintro5.mp3', 
          'gulyanananeyintro6.mp3',  
          'gulyanananeyintro7.mp3', 
          'gulyanananeyintro8.mp3',  
          'gulyanananeyintro9.mp3', 
          'gulyanananeyintro10.mp3',  
          'gulyanananeyintro11.mp3'],  
   song:'gulyanananey.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: gulya / cancion: na na ney &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[26] = { 
   intro:['yallaintro1.mp3', 
          'yallaintro2.mp3',  
          'yallaintro3.mp3', 
          'yallaintro4.mp3',  
          'yallaintro5.mp3', 
          'yallaintro6.mp3',  
          'yallaintro7.mp3', 
          'yallaintro8.mp3',  
          'yallaintro9.mp3', 
          'yallaintro10.mp3',  
          'yallaintro11.mp3', 
          'yallaintro12.mp3',  
          'yallaintro13.mp3'],  
   song:'innayalla.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: inna / cancion: yalla &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[27] = { 
   intro:['uyghurdancemixintro1.mp3', 
          'uyghurdancemixintro2.mp3',  
          'uyghurdancemixintro3.mp3', 
          'uyghurdancemixintro4.mp3',  
          'uyghurdancemixintro5.mp3', 
          'uyghurdancemixintro6.mp3',  
          'uyghurdancemixintro7.mp3', 
          'uyghurdancemixintro8.mp3',  
          'uyghurdancemixintro9.mp3', 
          'uyghurdancemixintro10.mp3',  
          'uyghurdancemixintro11.mp3', 
          'uyghurdancemixintro12.mp3',  
          'uyghurdancemixintro13.mp3'],  
   song:'ablimitjanmemetuyghurdancemix.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: ablimitjan memet / cancion: uyghur dance &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[28] = { 
   intro:['derindarbeintro1.mp3', 
          'derindarbeintro2.mp3',  
          'derindarbeintro3.mp3', 
          'derindarbeintro4.mp3',  
          'derindarbeintro5.mp3', 
          'derindarbeintro6.mp3',  
          'derindarbeintro7.mp3', 
          'derindarbeintro8.mp3',  
          'derindarbeintro9.mp3', 
          'derindarbeintro10.mp3',  
          'derindarbeintro11.mp3', 
          'derindarbeintro12.mp3',  
          'derindarbeintro13.mp3'],  
   song:'tugbaozerkderindarbe.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: Tuğba Özerk / cancion: derin darbe &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[29] = { 
   intro:['gamsizintro1.mp3', 
          'gamsizintro2.mp3',  
          'gamsizintro3.mp3', 
          'gamsizintro4.mp3',  
          'gamsizintro5.mp3', 
          'gamsizintro6.mp3',  
          'gamsizintro7.mp3', 
          'gamsizintro8.mp3',  
          'gamsizintro9.mp3', 
          'gamsizintro10.mp3',  
          'gamsizintro11.mp3'],  
   song:'hilalcebeciydogusgamsiz.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: Hilal Cebeci y Doğuş / cancion: gamsiz &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[30] = { 
   intro:['madinabuibuiintro1.mp3', 
          'madinabuibuiintro2.mp3',  
          'madinabuibuiintro3.mp3', 
          'madinabuibuiintro4.mp3',  
          'madinabuibuiintro5.mp3', 
          'madinabuibuiintro6.mp3',  
          'madinabuibuiintro7.mp3', 
          'madinabuibuiintro8.mp3',  
          'madinabuibuiintro9.mp3', 
          'madinabuibuiintro10.mp3',  
          'madinabuibuiintro11.mp3' ],  
   song:'madinaibragimovabuibui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: madina ibragimova / cancion: bui-bui &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[31] = { 
   intro:['tristarbuibuiintro1.mp3', 
          'tristarbuibuiintro2.mp3',  
          'tristarbuibuiintro3.mp3', 
          'tristarbuibuiintro4.mp3',  
          'tristarbuibuiintro5.mp3', 
          'tristarbuibuiintro6.mp3',  
          'tristarbuibuiintro7.mp3', 
          'tristarbuibuiintro8.mp3',  
          'tristarbuibuiintro9.mp3', 
          'tristarbuibuiintro10.mp3',  
          'tristarbuibuiintro11.mp3'],  
   song:'grupotristarbuibui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: kirguistan (🇰🇬) / interprete: grupo tristar / cancion: bui-bui &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[32] = { 
   intro:['mechtyotebeintro1.mp3', 
          'mechtyotebeintro2.mp3',  
          'mechtyotebeintro3.mp3', 
          'mechtyotebeintro4.mp3',  
          'mechtyotebeintro5.mp3', 
          'mechtyotebeintro6.mp3',  
          'mechtyotebeintro7.mp3', 
          'mechtyotebeintro8.mp3',  
          'mechtyotebeintro9.mp3', 
          'mechtyotebeintro10.mp3',  
          'mechtyotebeintro11.mp3'],  
   song:'fatimarabadanovaypieraijomechtyotebe.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima rabadanova y pier aijo / cancion: mechty o tebe &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[33] = { 
   intro:['izdaxmayliaginadoslaintro1.mp3', 
          'izdaxmayliaginadoslaintro2.mp3',  
          'izdaxmayliaginadoslaintro3.mp3', 
          'izdaxmayliaginadoslaintro4.mp3',  
          'izdaxmayliaginadoslaintro5.mp3', 
          'izdaxmayliaginadoslaintro6.mp3',  
          'izdaxmayliaginadoslaintro7.mp3', 
          'izdaxmayliaginadoslaintro8.mp3',  
          'izdaxmayliaginadoslaintro9.mp3', 
          'izdaxmayliaginadoslaintro10.mp3',  
          'izdaxmayliaginadoslaintro11.mp3'],  
   song:'yusupaliroziizdaxmayliaginadosla.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: yusup ali rozi / cancion: izdaxmayli agina dosla &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[34] = { 
   intro:['oynaoynaintro1.mp3', 
          'oynaoynaintro2.mp3',  
          'oynaoynaintro3.mp3', 
          'oynaoynaintro4.mp3',  
          'oynaoynaintro5.mp3', 
          'oynaoynaintro6.mp3',  
          'oynaoynaintro7.mp3', 
          'oynaoynaintro8.mp3',  
          'oynaoynaintro9.mp3', 
          'oynaoynaintro10.mp3',  
          'oynaoynaintro11.mp3', 
          'oynaoynaintro12.mp3', 
          'oynaoynaintro13.mp3', 
          'oynaoynaintro14.mp3', 
          'oynaoynaintro15.mp3'],  
   song:'maratsautovoyna.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Kazajistán (🇰🇿) / interprete: Marat Sautov / cancion: oyna oyna  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[35] = { 
   intro:['dujtarakifarjoriintro1.mp3', 
          'dujtarakifarjoriintro2.mp3',  
          'dujtarakifarjoriintro3.mp3', 
          'dujtarakifarjoriintro4.mp3',  
          'dujtarakifarjoriintro5.mp3', 
          'dujtarakifarjoriintro6.mp3',  
          'dujtarakifarjoriintro7.mp3', 
          'dujtarakifarjoriintro8.mp3',  
          'dujtarakifarjoriintro9.mp3', 
          'dujtarakifarjoriintro10.mp3',  
          'dujtarakifarjoriintro11.mp3'],  
   song:'zulaykhomahmadshoevadukhtarakifarkhori.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Tayikistán (🇹🇯) / interprete: Zulaykho Mahmadshoeva / cancion: Dukhtaraki Farkhori  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[36] = { 
   intro:['lovemeintro1.mp3', 
          'lovemeintro2.mp3',  
          'lovemeintro3.mp3', 
          'lovemeintro4.mp3',  
          'lovemeintro5.mp3', 
          'lovemeintro6.mp3',  
          'lovemeintro7.mp3', 
          'lovemeintro8.mp3',  
          'lovemeintro9.mp3', 
          'lovemeintro10.mp3',  
          'lovemeintro11.mp3'],  
   song:'fatimarabadanovaykurbangusaykhanovloveme.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: fatima rabadanova y kurban gusaykhanov / cancion: love me  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[37] = { 
   intro:['tepegoepaintro1.mp3', 
          'tepegoepaintro2.mp3', 
          'tepegoepaintro3.mp3', 
          'tepegoepaintro4.mp3',  
          'tepegoepaintro5.mp3', 
          'tepegoepaintro6.mp3',  
          'tepegoepaintro7.mp3', 
          'tepegoepaintro8.mp3',  
          'tepegoepaintro9.mp3', 
          'tepegoepaintro10.mp3',  
          'tepegoepaintro11.mp3'],  
   song:'alexferraritepegoepa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: brasil (🇧🇷) / interprete: alex ferrari / cancion: te pego e pa  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[38] = { 
   intro:['kisskissintro1.mp3', 
          'kisskissintro2.mp3', 
          'kisskissintro3.mp3', 
          'kisskissintro4.mp3',  
          'kisskissintro5.mp3', 
          'kisskissintro6.mp3',  
          'kisskissintro7.mp3', 
          'kisskissintro8.mp3',  
          'kisskissintro9.mp3', 
          'kisskissintro10.mp3',  
          'kisskissintro11.mp3'],  
   song:'tarkankisskiss.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: tarkan / cancion: kiss kiss (şimarik)  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }    

 list1[39] = { 
   intro:['schustermeenamoreintro1.mp3', 
          'schustermeenamoreintro2.mp3',  
          'schustermeenamoreintro3.mp3', 
          'schustermeenamoreintro4.mp3',  
          'schustermeenamoreintro5.mp3', 
          'schustermeenamoreintro6.mp3',  
          'schustermeenamoreintro7.mp3', 
          'schustermeenamoreintro8.mp3',  
          'schustermeenamoreintro9.mp3', 
          'schustermeenamoreintro10.mp3',  
          'schustermeenamoreintro11.mp3'],  
   song:'augustoschustermeenamore.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: augusto schuster / cancion: me enamore  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[40] = { 
   intro:['dancingondangerousintro1.mp3', 
          'dancingondangerousintro2.mp3', 
          'dancingondangerousintro3.mp3', 
          'dancingondangerousintro4.mp3',  
          'dancingondangerousintro5.mp3', 
          'dancingondangerousintro6.mp3',  
          'dancingondangerousintro7.mp3', 
          'dancingondangerousintro8.mp3',  
          'dancingondangerousintro9.mp3', 
          'dancingondangerousintro10.mp3',  
          'dancingondangerousintro11.mp3'],  
   song:'imanbekseanpaulsofiareyesdancingondangerous.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: kazajistan (🇰🇿) - jamaica (🇯🇲) - mexico (🇲🇽) / interprete: imanbek - sean paul - sofia reyes / cancion: dancing on dangerous  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[41] = { 
   intro:['schusterhastaelamanecerintro1.mp3', 
          'schusterhastaelamanecerintro2.mp3', 
          'schusterhastaelamanecerintro3.mp3', 
          'schusterhastaelamanecerintro4.mp3', 
          'schusterhastaelamanecerintro5.mp3', 
          'schusterhastaelamanecerintro6.mp3',  
          'schusterhastaelamanecerintro7.mp3', 
          'schusterhastaelamanecerintro8.mp3',  
          'schusterhastaelamanecerintro9.mp3', 
          'schusterhastaelamanecerintro10.mp3',  
          'schusterhastaelamanecerintro11.mp3'],  
   song:'augustoschusterhastaelamanecer.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: augusto schuster / cancion: hasta el amanecer  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[42] = { 
   intro:['bailamosintro1.mp3', 
          'bailamosintro2.mp3', 
          'bailamosintro3.mp3', 
          'bailamosintro4.mp3',  
          'bailamosintro5.mp3', 
          'bailamosintro6.mp3',  
          'bailamosintro7.mp3', 
          'bailamosintro8.mp3',  
          'bailamosintro9.mp3', 
          'bailamosintro10.mp3',  
          'bailamosintro11.mp3'],  
   song:'enriqueiglesiasbailamos.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: bailamos  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[43] = { 
   intro:['unanochemasintro1.mp3', 
          'unanochemasintro2.mp3', 
          'unanochemasintro3.mp3', 
          'unanochemasintro4.mp3',  
          'unanochemasintro5.mp3', 
          'unanochemasintro6.mp3',  
          'unanochemasintro7.mp3', 
          'unanochemasintro8.mp3',  
          'unanochemasintro9.mp3', 
          'unanochemasintro10.mp3',  
          'unanochemasintro11.mp3'],  
   song:'jenniferlopezunanochemas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: jennifer lopez ( j-lo ) / cancion: una noche mas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[44] = { 
   intro:['unañosinlluviaintro1.mp3', 
          'unañosinlluviaintro2.mp3',  
          'unañosinlluviaintro3.mp3', 
          'unañosinlluviaintro4.mp3',  
          'unañosinlluviaintro5.mp3', 
          'unañosinlluviaintro6.mp3',  
          'unañosinlluviaintro7.mp3', 
          'unañosinlluviaintro8.mp3',  
          'unañosinlluviaintro9.mp3', 
          'unañosinlluviaintro10.mp3',  
          'unañosinlluviaintro11.mp3'],  
   song:'selenagomezunanosinlluvia.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: selena gomez / cancion: un año sin lluvia  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[45] = { 
   intro:['genioatrapadointro1.mp3', 
          'genioatrapadointro2.mp3', 
          'genioatrapadointro3.mp3', 
          'genioatrapadointro4.mp3',  
          'genioatrapadointro5.mp3', 
          'genioatrapadointro6.mp3',  
          'genioatrapadointro7.mp3', 
          'genioatrapadointro8.mp3',  
          'genioatrapadointro9.mp3', 
          'genioatrapadointro10.mp3',  
          'genioatrapadointro11.mp3'],  
   song:'christinaaguileragenioatrapado.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: christina aguilera / cancion: genio atrapado  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[46] = { 
   intro:['mienteintro1.mp3', 
          'mienteintro2.mp3', 
          'mienteintro3.mp3', 
          'mienteintro4.mp3',  
          'mienteintro5.mp3', 
          'mienteintro6.mp3',  
          'mienteintro7.mp3', 
          'mienteintro8.mp3',  
          'mienteintro9.mp3', 
          'mienteintro10.mp3',  
          'mienteintro11.mp3'],  
   song:'enriqueiglesiasmiente.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: miente  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[47] = { 
   intro:['danceagainintro1.mp3', 
          'danceagainintro2.mp3', 
          'danceagainintro3.mp3', 
          'danceagainintro4.mp3',  
          'danceagainintro5.mp3', 
          'danceagainintro6.mp3',  
          'danceagainintro7.mp3', 
          'danceagainintro8.mp3',  
          'danceagainintro9.mp3', 
          'danceagainintro10.mp3',  
          'danceagainintro11.mp3'],  
   song:'jenniferlopezypitbulldanceagain.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: jennifer lopez y pitbull / cancion: dance again  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[48] = { 
   intro:['dimeintro1.mp3', 
          'dimeintro2.mp3', 
          'dimeintro3.mp3', 
          'dimeintro4.mp3',  
          'dimeintro5.mp3', 
          'dimeintro6.mp3',  
          'dimeintro7.mp3', 
          'dimeintro8.mp3',  
          'dimeintro9.mp3', 
          'dimeintro10.mp3',  
          'dimeintro11.mp3'],  
   song:'karenpaoladime.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: karen paola / cancion: dime  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[49] = { 
   intro:['summerloveintro1.mp3', 
          'summerloveintro2.mp3', 
          'summerloveintro3.mp3', 
          'summerloveintro4.mp3',  
          'summerloveintro5.mp3', 
          'summerloveintro6.mp3',  
          'summerloveintro7.mp3', 
          'summerloveintro8.mp3',  
          'summerloveintro9.mp3', 
          'summerloveintro10.mp3',  
          'summerloveintro11.mp3'],  
   song:'karenoliviersummerlove.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) / interprete: karen olivier / cancion: summer love  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[50] = { 
   intro:['nobodylikeyouintro1.mp3', 
          'nobodylikeyouintro2.mp3',  
          'nobodylikeyouintro3.mp3', 
          'nobodylikeyouintro4.mp3',  
          'nobodylikeyouintro5.mp3', 
          'nobodylikeyouintro6.mp3',  
          'nobodylikeyouintro7.mp3', 
          'nobodylikeyouintro8.mp3',  
          'nobodylikeyouintro9.mp3', 
          'nobodylikeyouintro10.mp3',  
          'nobodylikeyouintro11.mp3'],  
   song:'francoelgorilayoneillnobodylikeyou.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: puerto rico (🇵🇷) / interprete: franco el gorila y o'neill / cancion: nobody like you   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[51] = { 
   intro:['taubataubaintro1.mp3', 
          'taubataubaintro2.mp3', 
          'taubataubaintro3.mp3', 
          'taubataubaintro4.mp3',  
          'taubataubaintro5.mp3', 
          'taubataubaintro6.mp3',  
          'taubataubaintro7.mp3', 
          'taubataubaintro8.mp3',  
          'taubataubaintro9.mp3', 
          'taubataubaintro10.mp3',  
          'taubataubaintro11.mp3'],  
   song:'karanaujlataubatauba.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) / interprete: karan aujla / cancion: tauba tauba   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[52] = { 
   intro:['laultimatentacionintro1.mp3', 
          'laultimatentacionintro2.mp3', 
          'laultimatentacionintro3.mp3', 
          'laultimatentacionintro4.mp3',  
          'laultimatentacionintro5.mp3', 
          'laultimatentacionintro6.mp3',  
          'laultimatentacionintro7.mp3', 
          'laultimatentacionintro8.mp3',  
          'laultimatentacionintro9.mp3', 
          'laultimatentacionintro10.mp3',  
          'laultimatentacionintro11.mp3'],  
   song:'mariajosequintanillaluisjarafrancoelgorilalaultimatentacion.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: chile (🇨🇱) - puerto rico (🇵🇷) / interprete: maria jose quintanilla - luis jara - franco el gorila / cancion: la ultima tentacion  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[53] = { 
   intro:['meresapnokiraniintro1.mp3', 
          'meresapnokiraniintro2.mp3',  
          'meresapnokiraniintro3.mp3', 
          'meresapnokiraniintro4.mp3',  
          'meresapnokiraniintro5.mp3', 
          'meresapnokiraniintro6.mp3',  
          'meresapnokiraniintro7.mp3', 
          'meresapnokiraniintro8.mp3',  
          'meresapnokiraniintro9.mp3', 
          'meresapnokiraniintro10.mp3',  
          'meresapnokiraniintro11.mp3'],  
   song:'tamanabatiadiviakumarmeresapnokirani.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: india (🇮🇳) / interprete: Tamanna Bhatia y Divya Kumar / cancion: mere sapno ki rani  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[54] = { 
   intro:['istoriyaintro1.mp3', 
          'istoriyaintro2.mp3', 
          'istoriyaintro3.mp3', 
          'istoriyaintro4.mp3',  
          'istoriyaintro5.mp3', 
          'istoriyaintro6.mp3',  
          'istoriyaintro7.mp3', 
          'istoriyaintro8.mp3',  
          'istoriyaintro9.mp3', 
          'istoriyaintro10.mp3',  
          'istoriyaintro11.mp3'],  
   song:'myroistoriya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: MY-RO / cancion: istoriya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[55] = { 
   intro:['jiumengintro1.mp3', 
          'jiumengintro2.mp3', 
          'jiumengintro3.mp3', 
          'jiumengintro4.mp3',  
          'jiumengintro5.mp3', 
          'jiumengintro6.mp3',  
          'jiumengintro7.mp3', 
          'jiumengintro8.mp3',  
          'jiumengintro9.mp3', 
          'jiumengintro10.mp3',  
          'jiumengintro11.mp3'],  
   song:'tongxinjiumeng.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: tong xin / cancion: jiu meng (dj version)  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[56] = { 
   intro:['avishnyakrasnayaintro1.mp3', 
          'avishnyakrasnayaintro2.mp3', 
          'avishnyakrasnayaintro3.mp3', 
          'avishnyakrasnayaintro4.mp3',  
          'avishnyakrasnayaintro5.mp3', 
          'avishnyakrasnayaintro6.mp3',  
          'avishnyakrasnayaintro7.mp3', 
          'avishnyakrasnayaintro8.mp3',  
          'avishnyakrasnayaintro9.mp3', 
          'avishnyakrasnayaintro10.mp3',  
          'avishnyakrasnayaintro11.mp3'],  
   song:'kristinasokolovaavishnyakrasnaya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: kristina sokolova / cancion: a vishnya krasnaya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[57] = { 
   intro:['nabelompokryvaleyanvaryaintro1.mp3', 
          'nabelompokryvaleyanvaryaintro2.mp3',  
          'nabelompokryvaleyanvaryaintro3.mp3', 
          'nabelompokryvaleyanvaryaintro4.mp3',  
          'nabelompokryvaleyanvaryaintro5.mp3', 
          'nabelompokryvaleyanvaryaintro6.mp3',  
          'nabelompokryvaleyanvaryaintro7.mp3', 
          'nabelompokryvaleyanvaryaintro8.mp3',  
          'nabelompokryvaleyanvaryaintro9.mp3', 
          'nabelompokryvaleyanvaryaintro10.mp3',  
          'nabelompokryvaleyanvaryaintro11.mp3'],  
   song:'kamazznabelompokryvaleyanvarya.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: kamazz / cancion: na belom pokryvale yanvarya  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[58] = { 
   intro:['nidedaanintro1.mp3', 
          'nidedaanintro2.mp3', 
          'nidedaanintro3.mp3', 
          'nidedaanintro4.mp3',  
          'nidedaanintro5.mp3', 
          'nidedaanintro6.mp3',  
          'nidedaanintro7.mp3', 
          'nidedaanintro8.mp3',  
          'nidedaanintro9.mp3', 
          'nidedaanintro10.mp3',  
          'nidedaanintro11.mp3'],  
   song:'ziyaonidedaan.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: zǐ yáo / cancion: Nǐ de dá'àn  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[59] = { 
   intro:['oistamamintro1.mp3', 
          'oistamamintro2.mp3', 
          'oistamamintro3.mp3', 
          'oistamamintro4.mp3',  
          'oistamamintro5.mp3', 
          'oistamamintro6.mp3',  
          'oistamamintro7.mp3', 
          'oistamamintro8.mp3',  
          'oistamamintro9.mp3', 
          'oistamamintro10.mp3',  
          'oistamamintro11.mp3'],  
   song:'mumtazatesoistamam.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: turquia (🇹🇷) / interprete: mümtaz ateş / cancion: o iş tamam &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[60] = { 
   intro:['keerintro1.mp3', 
          'keerintro2.mp3', 
          'keerintro3.mp3', 
          'keerintro4.mp3',  
          'keerintro5.mp3', 
          'keerintro6.mp3',  
          'keerintro7.mp3', 
          'keerintro8.mp3',  
          'keerintro9.mp3', 
          'keerintro10.mp3',  
          'keerintro11.mp3'],  
   song:'chinchiuchekeer.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: china (🇨🇳) / interprete: jīnjiǔ zhé / cancion: Kē er  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[61] = { 
   intro:['echamelaculpaintro1.mp3', 
          'echamelaculpaintro2.mp3',  
          'echamelaculpaintro3.mp3', 
          'echamelaculpaintro4.mp3',  
          'echamelaculpaintro5.mp3', 
          'echamelaculpaintro6.mp3',  
          'echamelaculpaintro7.mp3', 
          'echamelaculpaintro8.mp3',  
          'echamelaculpaintro9.mp3', 
          'echamelaculpaintro10.mp3',  
          'echamelaculpaintro11.mp3'],  
   song:'luisfonsiydemilovatoechamelaculpa.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: puerto rico (🇵🇷) - estados unidos (🇺🇸) / interprete: luis fonsi y demi lovato / cancion: echame la culpa  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[62] = { 
   intro:['glowenosdogoryintro1.mp3',  
          'glowenosdogoryintro2.mp3', 
          'glowenosdogoryintro3.mp3',  
          'glowenosdogoryintro4.mp3',  
          'glowenosdogoryintro5.mp3',  
          'glowenosdogoryintro6.mp3',  
          'glowenosdogoryintro7.mp3',  
          'glowenosdogoryintro8.mp3',  
          'glowenosdogoryintro9.mp3',  
          'glowenosdogoryintro10.mp3',  
          'glowenosdogoryintro11.mp3', 
          'glowenosdogoryintro12.mp3',  
          'glowenosdogoryintro13.mp3',  
          'glowenosdogoryintro14.mp3',  
          'glowenosdogoryintro15.mp3'],  
   song:'pectuskasiacerekwickaglowenosdogory.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: polonia (🇵🇱) / interpretes: pectus & Kasia Cerekwicka / cancion: Głowę noś do góry   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[63] = { 
   intro:['ritmototalintro1.mp3',  
          'ritmototalintro2.mp3', 
          'ritmototalintro3.mp3',  
          'ritmototalintro4.mp3',  
          'ritmototalintro5.mp3',  
          'ritmototalintro6.mp3',  
          'ritmototalintro7.mp3',  
          'ritmototalintro8.mp3',  
          'ritmototalintro9.mp3',  
          'ritmototalintro10.mp3',  
          'ritmototalintro11.mp3'],  
   song:'enriqueiglesiasritmototal.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: españa (🇪🇸) / interprete: enrique iglesias / cancion: ritmo total   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[64] = { 
   intro:['chtochtylyetaintro1.mp3',  
          'chtochtylyetaintro2.mp3', 
          'chtochtylyetaintro3.mp3',  
          'chtochtylyetaintro4.mp3',  
          'chtochtylyetaintro5.mp3',  
          'chtochtylyetaintro6.mp3',  
          'chtochtylyetaintro7.mp3',  
          'chtochtylyetaintro8.mp3',  
          'chtochtylyetaintro9.mp3',  
          'chtochtylyetaintro10.mp3',  
          'chtochtylyetaintro11.mp3'],  
   song:'yekaterinadenisovachtochtylyeta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rusia (🇷🇺) / interprete: Yekaterina Denisova / cancion: Chto zh ty lyeta   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[65] = { 
   intro:['tejocicuminteameaintro1.mp3',  
          'tejocicuminteameaintro2.mp3',  
          'tejocicuminteameaintro3.mp3',  
          'tejocicuminteameaintro4.mp3',  
          'tejocicuminteameaintro5.mp3',  
          'tejocicuminteameaintro6.mp3',  
          'tejocicuminteameaintro7.mp3',  
          'tejocicuminteameaintro8.mp3',  
          'tejocicuminteameaintro9.mp3',  
          'tejocicuminteameaintro10.mp3',  
          'tejocicuminteameaintro11.mp3'],  
   song:'sandranmariusnedelcutejocicuminteamea.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: Sandra N. feat. Marius Nedelcu / cancion: Te joci cu mintea mea   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[66] = { 
   intro:['introziintro1.mp3',  
          'introziintro2.mp3', 
          'introziintro3.mp3',  
          'introziintro4.mp3',  
          'introziintro5.mp3',  
          'introziintro6.mp3',  
          'introziintro7.mp3',  
          'introziintro8.mp3',  
          'introziintro9.mp3',  
          'introziintro10.mp3',  
          'introziintro11.mp3'],  
   song:'valentindinuanyaintrozi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: rumania (🇷🇴) / interprete: valentin dinu y anya / cancion: intr-o zi   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[67] = { 
   intro:['ludanocintro1.mp3', 
          'ludanocintro2.mp3',   
          'ludanocintro3.mp3',   
          'ludanocintro4.mp3',    
          'ludanocintro5.mp3',    
          'ludanocintro6.mp3',    
          'ludanocintro7.mp3',    
          'ludanocintro8.mp3',    
          'ludanocintro9.mp3',   
          'ludanocintro10.mp3',    
          'ludanocintro11.mp3',    
          'ludanocintro12.mp3',    
          'ludanocintro13.mp3',    
          'ludanocintro14.mp3',    
          'ludanocintro15.mp3' ],    
   song:'nikaludanoc.mp3',   
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Serbia (🇷🇸) / interprete: Nika / cancion: Luda Noć (Crazy Night)  &nbsp&nbsp&nbsp&#160&#160&#160"   
 }  

 list1[68] = { 
   intro:['pananzoriintro1.mp3',  
          'pananzoriintro2.mp3', 
          'pananzoriintro3.mp3',  
          'pananzoriintro4.mp3',  
          'pananzoriintro5.mp3',  
          'pananzoriintro6.mp3',  
          'pananzoriintro7.mp3',  
          'pananzoriintro8.mp3',  
          'pananzoriintro9.mp3',  
          'pananzoriintro10.mp3',  
          'pananzoriintro11.mp3'],  
   song:'vasilemacoveipananzori.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: moldavia (🇲🇩) / interprete: vasile macovei / cancion: Până-n zori   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[69] = { 
   intro:['amanamanintro1.mp3',  
          'amanamanintro2.mp3', 
          'amanamanintro3.mp3',  
          'amanamanintro4.mp3',  
          'amanamanintro5.mp3',  
          'amanamanintro6.mp3',  
          'amanamanintro7.mp3',  
          'amanamanintro8.mp3',  
          'amanamanintro9.mp3',  
          'amanamanintro10.mp3',  
          'amanamanintro11.mp3'],  
   song:'eldaramanaman.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: eldar / cancion: Aman-Aman  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[70] = { 
   intro:['guelmeneintro1.mp3',  
          'guelmeneintro2.mp3', 
          'guelmeneintro3.mp3',  
          'guelmeneintro4.mp3',  
          'guelmeneintro5.mp3',  
          'guelmeneintro6.mp3',  
          'guelmeneintro7.mp3',  
          'guelmeneintro8.mp3',  
          'guelmeneintro9.mp3',  
          'guelmeneintro10.mp3',  
          'guelmeneintro11.mp3'],  
   song:'sevdayahyayevagelmene.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: Sevda Yahyayeva / cancion: Gəl Mənə  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[71] = { 
   intro:['seviramintro1.mp3',  
          'seviramintro2.mp3', 
          'seviramintro3.mp3',  
          'seviramintro4.mp3',  
          'seviramintro5.mp3',  
          'seviramintro6.mp3',  
          'seviramintro7.mp3',  
          'seviramintro8.mp3',  
          'seviramintro9.mp3',  
          'seviramintro10.mp3',  
          'seviramintro11.mp3'],  
   song:'miriyusifseviram.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Azerbaijan (🇦🇿) / interprete: miri yusif / cancion: Sevirəm  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[72] = { 
   intro:['kameliaintro1.mp3',  
          'kameliaintro2.mp3', 
          'kameliaintro3.mp3',  
          'kameliaintro4.mp3',  
          'kameliaintro5.mp3',  
          'kameliaintro6.mp3',  
          'kameliaintro7.mp3',  
          'kameliaintro8.mp3',  
          'kameliaintro9.mp3',  
          'kameliaintro10.mp3',  
          'kameliaintro11.mp3'],  
   song:'akcentlidiabubleddynuneskamelia.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Rumania (🇷🇴) - Brasil (🇧🇷) / interprete: akcent con lidia buble y ddy nunes / cancion: Kamelia  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[73] = { 
   intro:['miloyavointro1.mp3',  
          'miloyavointro2.mp3',  
          'miloyavointro3.mp3',  
          'miloyavointro4.mp3',  
          'miloyavointro5.mp3',  
          'miloyavointro6.mp3',  
          'miloyavointro7.mp3',  
          'miloyavointro8.mp3',  
          'miloyavointro9.mp3',  
          'miloyavointro10.mp3',  
          'miloyavointro11.mp3'],  
   song:'avrahamtalbenaiabarabimiloyavo.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: Avraham Tal y Benaia Barabi / cancion: mi lo yavo  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[74] = { 
   intro:['bonadliktaeshintro1.mp3',  
          'bonadliktaeshintro2.mp3',  
          'bonadliktaeshintro3.mp3',  
          'bonadliktaeshintro4.mp3',  
          'bonadliktaeshintro5.mp3',  
          'bonadliktaeshintro6.mp3',  
          'bonadliktaeshintro7.mp3',  
          'bonadliktaeshintro8.mp3',  
          'bonadliktaeshintro9.mp3',  
          'bonadliktaeshintro10.mp3',  
          'bonadliktaeshintro11.mp3'],  
   song:'itzikorlevbonadliktaesh.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: itzik orlev / cancion: bo nadlik t'esh  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[75] = { 
   intro:['majshavottovotintro1.mp3',  
          'majshavottovotintro2.mp3',  
          'majshavottovotintro3.mp3',  
          'majshavottovotintro4.mp3',  
          'majshavottovotintro5.mp3',  
          'majshavottovotintro6.mp3',  
          'majshavottovotintro7.mp3',  
          'majshavottovotintro8.mp3',  
          'majshavottovotintro9.mp3',  
          'majshavottovotintro10.mp3',  
          'majshavottovotintro11.mp3'],  
   song:'motiweissmachshavottovot.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Israel (🇮🇱) / interprete: motty weiss / cancion: Machshavot Tovot  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[76] = { 
   intro:['yamaintro1.mp3',  
          'yamaintro2.mp3',  
          'yamaintro3.mp3',  
          'yamaintro4.mp3',  
          'yamaintro5.mp3',  
          'yamaintro6.mp3',  
          'yamaintro7.mp3',  
          'yamaintro8.mp3',  
          'yamaintro9.mp3',  
          'yamaintro10.mp3',  
          'yamaintro11.mp3'],  
   song:'bennyfriedmanyama.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: estados unidos (🇺🇸) / interprete: benny friedman / cancion: YAMA  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[77] = { 
   intro:['sanavaguiintro1.mp3',  
          'sanavaguiintro2.mp3', 
          'sanavaguiintro3.mp3',  
          'sanavaguiintro4.mp3',  
          'sanavaguiintro5.mp3',  
          'sanavaguiintro6.mp3',  
          'sanavaguiintro7.mp3',  
          'sanavaguiintro8.mp3',  
          'sanavaguiintro9.mp3',  
          'sanavaguiintro10.mp3',  
          'sanavaguiintro11.mp3'],  
   song:'ninosanavagui.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: nino / cancion: sa navagi  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[78] = { 
   intro:['theosintro1.mp3',  
          'theosintro2.mp3', 
          'theosintro3.mp3',  
          'theosintro4.mp3',  
          'theosintro5.mp3',  
          'theosintro6.mp3',  
          'theosintro7.mp3',  
          'theosintro8.mp3',  
          'theosintro9.mp3',  
          'theosintro10.mp3',  
          'theosintro11.mp3'],  
   song:'ninotheos.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: nino / cancion: theos  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[79] = { 
   intro:['dodnaintro1.mp3',  
          'dodnaintro2.mp3', 
          'dodnaintro3.mp3',  
          'dodnaintro4.mp3',  
          'dodnaintro5.mp3',  
          'dodnaintro6.mp3',  
          'dodnaintro7.mp3',  
          'dodnaintro8.mp3',  
          'dodnaintro9.mp3',  
          'dodnaintro10.mp3',  
          'dodnaintro11.mp3'],  
   song:'oksananasanovichdodna.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bielorrusia (🇧🇾) / interprete: oksana nasanovich / cancion: do dna  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[80] = { 
   intro:['paointro1.mp3',  
          'paointro2.mp3', 
          'paointro3.mp3',  
          'paointro4.mp3',  
          'paointro5.mp3',  
          'paointro6.mp3',  
          'paointro7.mp3',  
          'paointro8.mp3', 
          'paointro9.mp3',  
          'paointro10.mp3',  
          'paointro11.mp3'],  
   song:'iviadamoukonniemetaxapao.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: ívi adámou y konnie metaxa / cancion: páo  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[81] = { 
   intro:['opoumepasintro1.mp3',  
          'opoumepasintro2.mp3', 
          'opoumepasintro3.mp3',  
          'opoumepasintro4.mp3',  
          'opoumepasintro5.mp3',  
          'opoumepasintro6.mp3',  
          'opoumepasintro7.mp3',  
          'opoumepasintro8.mp3', 
          'opoumepasintro9.mp3',  
          'opoumepasintro10.mp3',  
          'opoumepasintro11.mp3'],  
   song:'kingsantonellaopoumepas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: kings y antonella / cancion: opou me pas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[82] = { 
   intro:['dyozoesintro1.mp3',  
          'dyozoesintro2.mp3', 
          'dyozoesintro3.mp3',  
          'dyozoesintro4.mp3',  
          'dyozoesintro5.mp3',  
          'dyozoesintro6.mp3',  
          'dyozoesintro7.mp3',  
          'dyozoesintro8.mp3', 
          'dyozoesintro9.mp3',  
          'dyozoesintro10.mp3',  
          'dyozoesintro11.mp3'],  
   song:'kingsantonelladyozoes.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: kings y Antonella / cancion: dyo zoes  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[83] = { 
   intro:['giatimetyrannasintro1.mp3',  
          'giatimetyrannasintro2.mp3', 
          'giatimetyrannasintro3.mp3',  
          'giatimetyrannasintro4.mp3',  
          'giatimetyrannasintro5.mp3',  
          'giatimetyrannasintro6.mp3',  
          'giatimetyrannasintro7.mp3',  
          'giatimetyrannasintro8.mp3', 
          'giatimetyrannasintro9.mp3',  
          'giatimetyrannasintro10.mp3',  
          'giatimetyrannasintro11.mp3'],  
   song:'dimitriskokotasgiatimetyrannas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: Dimítris Kókotas / cancion: Giatí Me Tyrannás  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[84] = { 
   intro:['byagayintro1.mp3',  
          'byagayintro2.mp3', 
          'byagayintro3.mp3',  
          'byagayintro4.mp3',  
          'byagayintro5.mp3',  
          'byagayintro6.mp3',  
          'byagayintro7.mp3',  
          'byagayintro8.mp3', 
          'byagayintro9.mp3',  
          'byagayintro10.mp3',  
          'byagayintro11.mp3'],  
   song:'slavigumzatakukubandbyagay.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Slavi, Gumzata & Ku-Ku Band / cancion: Byagay  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[85] = { 
   intro:['oshteintro1.mp3',  
          'oshteintro2.mp3', 
          'oshteintro3.mp3',  
          'oshteintro4.mp3',  
          'oshteintro5.mp3',  
          'oshteintro6.mp3',  
          'oshteintro7.mp3',  
          'oshteintro8.mp3', 
          'oshteintro9.mp3',  
          'oshteintro10.mp3',  
          'oshteintro11.mp3'],  
   song:'vanesaoshte.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: vanesa / cancion: oshte  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[86] = { 
   intro:['nainatintro1.mp3',  
          'nainatintro2.mp3', 
          'nainatintro3.mp3',  
          'nainatintro4.mp3',  
          'nainatintro5.mp3',  
          'nainatintro6.mp3',  
          'nainatintro7.mp3',  
          'nainatintro8.mp3', 
          'nainatintro9.mp3',  
          'nainatintro10.mp3',  
          'nainatintro11.mp3',  
          'nainatintro12.mp3'],  
   song:'poligenovanainat.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Poli Genova / cancion: Na Inat  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[87] = { 
   intro:['samotiintro1.mp3',  
          'samotiintro2.mp3', 
          'samotiintro3.mp3',  
          'samotiintro4.mp3',  
          'samotiintro5.mp3',  
          'samotiintro6.mp3',  
          'samotiintro7.mp3',  
          'samotiintro8.mp3', 
          'samotiintro9.mp3',  
          'samotiintro10.mp3',  
          'samotiintro11.mp3',  
          'samotiintro12.mp3'],  
   song:'lazarsamoti.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Lazar / cancion: Samo Ti  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[88] = { 
   intro:['dokraiintro1.mp3',  
          'dokraiintro2.mp3', 
          'dokraiintro3.mp3',  
          'dokraiintro4.mp3',  
          'dokraiintro5.mp3',  
          'dokraiintro6.mp3',  
          'dokraiintro7.mp3',  
          'dokraiintro8.mp3', 
          'dokraiintro9.mp3',  
          'dokraiintro10.mp3',  
          'dokraiintro11.mp3',  
          'dokraiintro12.mp3'],  
   song:'andreadokrai.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: ANDREA / cancion: Dokrai &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[89] = { 
   intro:['noshttagarmiintro1.mp3',  
          'noshttagarmiintro2.mp3', 
          'noshttagarmiintro3.mp3',  
          'noshttagarmiintro4.mp3',  
          'noshttagarmiintro5.mp3',  
          'noshttagarmiintro6.mp3',  
          'noshttagarmiintro7.mp3',  
          'noshttagarmiintro8.mp3', 
          'noshttagarmiintro9.mp3',  
          'noshttagarmiintro10.mp3',  
          'noshttagarmiintro11.mp3',  
          'noshttagarmiintro12.mp3'],  
   song:'galinlorenanoshttagarmi.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Galin & Lorena / cancion: NOSHTTA GARMI   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[90] = { 
   intro:['pecsaulesrietaintro1.mp3',  
          'pecsaulesrietaintro2.mp3', 
          'pecsaulesrietaintro3.mp3',  
          'pecsaulesrietaintro4.mp3',  
          'pecsaulesrietaintro5.mp3',  
          'pecsaulesrietaintro6.mp3',  
          'pecsaulesrietaintro7.mp3',  
          'pecsaulesrietaintro8.mp3', 
          'pecsaulesrietaintro9.mp3',  
          'pecsaulesrietaintro10.mp3',  
          'pecsaulesrietaintro11.mp3',  
          'pecsaulesrietaintro12.mp3'],  
   song:'denijsgriezenikolajspuzikovspecsaulesrieta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Denijs Grieze y Nikolajs Puzikovs / cancion: Pēc saules rieta  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[91] = { 
   intro:['garigaisariintro1.mp3',  
          'garigaisariintro2.mp3', 
          'garigaisariintro3.mp3',  
          'garigaisariintro4.mp3',  
          'garigaisariintro5.mp3',  
          'garigaisariintro6.mp3',  
          'garigaisariintro7.mp3',  
          'garigaisariintro8.mp3', 
          'garigaisariintro9.mp3',  
          'garigaisariintro10.mp3',  
          'garigaisariintro11.mp3',  
          'garigaisariintro12.mp3'],  
   song:'musiqqgarigaisari.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: musiqq (Marats Ogļezņevs y Emīls Balceris) / cancion: Garīgais arī   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[92] = { 
   intro:['muzikaplustpavenamintro1.mp3',  
          'muzikaplustpavenamintro2.mp3', 
          'muzikaplustpavenamintro3.mp3',  
          'muzikaplustpavenamintro4.mp3',  
          'muzikaplustpavenamintro5.mp3',  
          'muzikaplustpavenamintro6.mp3',  
          'muzikaplustpavenamintro7.mp3',  
          'muzikaplustpavenamintro8.mp3', 
          'muzikaplustpavenamintro9.mp3',  
          'muzikaplustpavenamintro10.mp3',  
          'muzikaplustpavenamintro11.mp3',  
          'muzikaplustpavenamintro12.mp3'],  
   song:'musiqqmuzikaplustpavenam.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: musiqq (Marats Ogļezņevs y Emīls Balceris) / cancion: Mūzika Plūst Pa Vēnām   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[93] = { 
   intro:['mannesanakintro1.mp3',  
          'mannesanakintro2.mp3', 
          'mannesanakintro3.mp3',  
          'mannesanakintro4.mp3',  
          'mannesanakintro5.mp3',  
          'mannesanakintro6.mp3',  
          'mannesanakintro7.mp3',  
          'mannesanakintro8.mp3', 
          'mannesanakintro9.mp3',  
          'mannesanakintro10.mp3',  
          'mannesanakintro11.mp3',  
          'mannesanakintro12.mp3',  
          'mannesanakintro13.mp3',  
          'mannesanakintro14.mp3' ],  
   song:'markusrivasamantatinamannesanak.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: MARKUS RIVA y SAMANTA TĪNA / cancion: MAN NESANĀK &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[94] = { 
   intro:['vinasvaraintro1.mp3',  
          'vinasvaraintro2.mp3', 
          'vinasvaraintro3.mp3',  
          'vinasvaraintro4.mp3',  
          'vinasvaraintro5.mp3',  
          'vinasvaraintro6.mp3',  
          'vinasvaraintro7.mp3',  
          'vinasvaraintro8.mp3', 
          'vinasvaraintro9.mp3',  
          'vinasvaraintro10.mp3',  
          'vinasvaraintro11.mp3',  
          'vinasvaraintro12.mp3',  
          'vinasvaraintro13.mp3',  
          'vinasvaraintro14.mp3' ],  
   song:'dweennikolajspuzikovsmixtypervinasvara.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Dween & Nikolajs Puzikovs pied. Mixtyper / cancion: Viņas varā &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[95] = { 
   intro:['tuesikarstaintro1.mp3',  
          'tuesikarstaintro2.mp3', 
          'tuesikarstaintro3.mp3',  
          'tuesikarstaintro4.mp3',  
          'tuesikarstaintro5.mp3',  
          'tuesikarstaintro6.mp3',  
          'tuesikarstaintro7.mp3',  
          'tuesikarstaintro8.mp3', 
          'tuesikarstaintro9.mp3',  
          'tuesikarstaintro10.mp3',  
          'tuesikarstaintro11.mp3',  
          'tuesikarstaintro12.mp3',  
          'tuesikarstaintro13.mp3',  
          'tuesikarstaintro14.mp3' ],  
   song:'dweennikolajspuzikovstuesikarsta.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Letonia (🇱🇻) / interprete: Dween un Nikolajs Puzikovs / cancion: Tu esi karsta &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[96] = { 
   intro:['netilistigaintro1.mp3',  
          'netilistigaintro2.mp3', 
          'netilistigaintro3.mp3',  
          'netilistigaintro4.mp3',  
          'netilistigaintro5.mp3',  
          'netilistigaintro6.mp3',  
          'netilistigaintro7.mp3',  
          'netilistigaintro8.mp3', 
          'netilistigaintro9.mp3',  
          'netilistigaintro10.mp3',  
          'netilistigaintro11.mp3',  
          'netilistigaintro12.mp3',  
          'netilistigaintro13.mp3',  
          'netilistigaintro14.mp3' ],  
   song:'mihaelamarinovanetilistiga.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Bulgaria (🇧🇬) / interprete: Mihaela Marinova / cancion: ne ti li stiga  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[97] = { 
   intro:['napasintro1.mp3',  
          'napasintro2.mp3', 
          'napasintro3.mp3',  
          'napasintro4.mp3',  
          'napasintro5.mp3',  
          'napasintro6.mp3',  
          'napasintro7.mp3',  
          'napasintro8.mp3', 
          'napasintro9.mp3',  
          'napasintro10.mp3',  
          'napasintro11.mp3',  
          'napasintro12.mp3',  
          'napasintro13.mp3',  
          'napasintro14.mp3' ],  
   song:'konstatinosgalanosnapas.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: Konstantinos Galanos / cancion: na pas  &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[98] = { 
   intro:['vradiaaksimerotaintro1.mp3',  
          'vradiaaksimerotaintro2.mp3', 
          'vradiaaksimerotaintro3.mp3',  
          'vradiaaksimerotaintro4.mp3',  
          'vradiaaksimerotaintro5.mp3',  
          'vradiaaksimerotaintro6.mp3',  
          'vradiaaksimerotaintro7.mp3',  
          'vradiaaksimerotaintro8.mp3', 
          'vradiaaksimerotaintro9.mp3',  
          'vradiaaksimerotaintro10.mp3',  
          'vradiaaksimerotaintro11.mp3',  
          'vradiaaksimerotaintro12.mp3',  
          'vradiaaksimerotaintro13.mp3',  
          'vradiaaksimerotaintro14.mp3' ],  
   song:'petrosiakovidisvradiaaksimerota.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Grecia (🇬🇷) / interprete: petros iakovidis / cancion: Vrádia Aksimérota   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  

 list1[99] = { 
   intro:['pecarareamuntilorintro1.mp3',  
          'pecarareamuntilorintro2.mp3', 
          'pecarareamuntilorintro3.mp3',  
          'pecarareamuntilorintro4.mp3',  
          'pecarareamuntilorintro5.mp3',  
          'pecarareamuntilorintro6.mp3',  
          'pecarareamuntilorintro7.mp3',  
          'pecarareamuntilorintro8.mp3', 
          'pecarareamuntilorintro9.mp3',  
          'pecarareamuntilorintro10.mp3',  
          'pecarareamuntilorintro11.mp3',  
          'pecarareamuntilorintro12.mp3',  
          'pecarareamuntilorintro13.mp3',  
          'pecarareamuntilorintro14.mp3' ],  
   song:'sandranpecarareamuntilor.mp3', 
   text:" &nbsp&nbsp&nbsp&#160&#160&#160 pais: Rumania (🇷🇴) / interprete: Sandra N / cancion: pe cararea muntilor   &nbsp&nbsp&nbsp&#160&#160&#160"  
 }  
 
